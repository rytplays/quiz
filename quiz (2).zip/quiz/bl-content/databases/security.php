<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "minutesBlocked": 5,
    "numberFailuresAllowed": 10,
    "blackList": []
}