<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "admin": {
        "nickname": "Admin",
        "firstName": "Administrator",
        "lastName": "",
        "role": "admin",
        "password": "dcce9ae6c61d6a4142955d5d9e6e2e901ae1187b",
        "salt": "600f07c93e0fb",
        "email": "",
        "registered": "2021-01-25 23:32:49",
        "tokenRemember": "",
        "tokenAuth": "050bd89f03f858eaf2d7ec345854fe97",
        "tokenAuthTTL": "2009-03-15 14:00",
        "twitter": "",
        "facebook": "",
        "instagram": "",
        "codepen": "",
        "linkedin": "",
        "github": "",
        "gitlab": ""
    }
}