<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "numberOfDays": 7,
    "label": "Visits",
    "excludeAdmins": false,
    "position": 1
}