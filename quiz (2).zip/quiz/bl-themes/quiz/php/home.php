<?php if (empty($content)): ?>
<div class="alert alert-info shadow-sm m-3 border-white" role="alert">
  No Quizzes found on this page. <a href="<?php echo $site->url(); ?>" class="alert-link">Back to Home</a>
</div>
<?php endif ?>



<div class="quizzes">

<?php foreach ($content as $page): ?>
	<a href="https://rytplays.com/quiz/play/index.html?source=<?php echo $page->custom('qi');?>" class="quiz">
		<div class="quiz-title"><?php echo $page->title(); ?></div>
		<div class="quiz-meta text-uppercase"><?php echo $page->date(); ?></div>
		<div class="quiz-meta"><?php echo $page->description(); ?></div>
	</a>
<?php endforeach ?>

</div>



<?php if (Paginator::numberOfPages()>1): ?>



<div class="d-flex justify-content-center my-5 ">
	<div class="btn-group btn-group-sm bg-white">
		<a class="btn btn-dark <?php if(!Paginator::showPrev()) echo 'disabled'; ?>" href="<?php echo Paginator::previousPageUrl() ?>">PREV</a>
		<a class="btn btn-dark" href="<?php echo $site->url(); ?>">HOME</a>
		<a class="btn btn-dark <?php if (!Paginator::showNext()) echo 'disabled'; ?>" href="<?php echo Paginator::nextPageUrl() ?>">NEXT</a>
	</div>
</div>
<?php endif ?>