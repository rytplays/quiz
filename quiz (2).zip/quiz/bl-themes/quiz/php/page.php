<?php Theme::plugins('pageBegin'); ?>
	
<?php Theme::plugins('pageEnd'); ?>


