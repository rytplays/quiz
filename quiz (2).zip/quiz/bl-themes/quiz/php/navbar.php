<header class="nbar-wrapper">
    <nav class="nbar">
        <div class="tbar">
            <div class="tbar-content-left">
                <div style="font-weight:normal" data-drawer-trigger="" aria-controls="drawer-name-left" aria-expanded="false" class="ic ic-menu ripple"></div>
                <a class="tbar-brand ripple" href="<?php echo Theme::siteUrl() ?>" title="RYTPLAYS JOBS"><?php echo $site->title() ?></a>
            </div>
            <div class="tbar-content-right">
                <a class="ic ic-facebook-colored ripple" data-prefix="ext" target="_blank" href="https://www.facebook.com/groups/2829964387247155/"></a>
                <a class="ic ic-telegram-colored ripple" data-prefix="ext" target="_blank" href="https://t.me/rytplays_jobs"></a>
                <a class="ic ic-home ripple" href="https://rytplays.com"></a>
            </div>
        </div>
        <div class="active-tag">
            <?php echo $categories->db[$url->slug()]['name'] ?? 'HOME'; ?>
        </div>
    </nav>
</header>





<nav class="drawer drawer-left" id="drawer-name-left" data-drawer-target>
    
    <div class="drawer-overlay" data-drawer-close="" tabindex="-1"></div>
    
    <div class="drawer-wrapper">

        <div class="drawer-header">
            <div class="drawer-title"><?php echo $site->title() ?></div>
            <div class="ic ic-close ripple" data-drawer-close></div>
        </div>

        <div class="drawer-content">
            <div class="drawer-links xcard"> 
                <div class="drawer-links-title">Categories</div>           
                <?php $items = getCategories();foreach ($items as $category) {echo '<a href="'.$category->permalink().'">'.$category->name().'</a>';}?>
            </div>
        </div>

    </div>

</nav>