<!DOCTYPE html>
<html lang="en">
<head>
<?php include(THEME_DIR_PHP.'head.php'); ?>
</head>
<body class="bg-solitude">
<?php Theme::plugins('siteBodyBegin'); ?>
<?php include(THEME_DIR_PHP.'navbar.php'); ?>
<?php
if ($WHERE_AM_I == 'page') 
{
include(THEME_DIR_PHP.'page.php');
}
else 
{
include(THEME_DIR_PHP.'home.php');
}
?>
	<?php include(THEME_DIR_PHP.'footer.php'); ?>
<?php Theme::plugins('siteBodyEnd'); ?>
</body>
</html>