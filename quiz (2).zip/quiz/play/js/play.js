const
        loader=document.getElementById("loader");
        div_title_bar=document.getElementById("div_title_bar"),
        btn_prev = document.getElementById("btn_prev"),
        btn_score = document.getElementById("btn_score"),
        btn_question_number = document.getElementById("btn_question_number"),
        btn_next = document.getElementById("btn_next"),
        
        div_question_panel = document.getElementById("div_question_panel"),
        div_question = document.getElementById("div_question"),
        div_option_1 = document.getElementById("div_option_1"),
        div_option_2 = document.getElementById("div_option_2"),
        div_option_3 = document.getElementById("div_option_3"),
        div_option_4 = document.getElementById("div_option_4"),

        div_score_panel = document.getElementById("div_score_panel"),
        div_total_question=document.getElementById("div_total_question"),
        div_attended_questions=document.getElementById("div_attended_questions"),
        div_correct_questions = document.getElementById("div_correct_questions"),
        div_incorrect_questions=document.getElementById("div_incorrect_questions"),
        div_score_percentage = document.getElementById("div_score_percentage");

        correct_ans_audio=new Audio("assets/sounds/correct.mp3"),
        wrong_ans_audio=new Audio("assets/sounds/wrong.mp3");



        var url_string = window.location.href;
        var url = new URL(url_string);
        if(url.searchParams.has("source"))
        {
            quiz_id = url.searchParams.get("source");
        }
        else
        {
            loader.innerHTML="NO SOURCE FOUND";
            throw new Error("NO SOURCE FOUND");
        }
        questions=[];
        total_questions=0;
        current_question=1;
        score=0;
        attended_questions=0;

        quiz_url = 'https://rytplays.com/studio.quiz/api/load-quiz.php?quiz_id='+quiz_id;


        function load_questions_from_url(url){
            $.post({ url : url})
            .done(function(response)
            {
                try
                {
                    response = JSON.parse(response);
                }
                catch(error)
                {
                    loader.innerHTML=error;
                }
                
                if(typeof(response)=="object")
                {
                    if(response.type=="success")
                    {
                        questions=response.data.questions;
                        total_questions=questions.length;
                        if(total_questions>0)
                        {
                            loader.style.display="none";
                            document.getElementById("main").style.display="block";
                            load_question(current_question);
                        }
                        else
                        {
                            loader.innerHTML="NO QUESTIONS FOUND";
                        }
                    }
                    else
                    {
                        loader.innerHTML=response.msg;
                    }
                    
                    
                }
                else
                {
                    loader.innerHTML="RESPONSE IS NOT A VALID JSON OBJECT";
                }
                
            })
            .fail(function(jqXHR,textStatus,exception)
            {
                loader.innerHTML=exception;
            });
        }
        
        load_questions_from_url(quiz_url);
        
       

        function load_question(question_number)
        {
            
            if(question_number>total_questions){
                show_score_panel();
                return;
            }
            else if(question_number<=0){
                wrong_ans_audio.play();
                return;
            }
            else{

            }

            window.clearTimeout();
            
            setTimeout(function(){
                div_question_panel.style.opacity=1;
            },100);

            current_question=question_number;
            btn_question_number.innerHTML=current_question+"/"+total_questions;
            div_option_1.style.background=
            div_option_2.style.background=
            div_option_3.style.background=
            div_option_4.style.background="#FFF";

            question=questions[question_number-1];
            div_question.innerHTML=question.question;
            div_option_1.innerHTML=question.option_1;
            div_option_2.innerHTML=question.option_2;
            div_option_3.innerHTML=question.option_3;
            div_option_4.innerHTML=question.option_4;


            div_option_1.setAttribute("data-correct",false);
            div_option_2.setAttribute("data-correct",false);
            div_option_3.setAttribute("data-correct",false);
            div_option_4.setAttribute("data-correct",false);
            
            try
            {
                var div_correct_ans=document.getElementById("div_option_"+question.answer);
                div_correct_ans.setAttribute("data-correct",true);

                if(question.u=="0")
                {
                    div_option_1.onclick=
                    div_option_2.onclick=
                    div_option_3.onclick=
                    div_option_4.onclick=
                    function()
                    {
                        div_option_1.onclick=
                        div_option_2.onclick=
                        div_option_3.onclick=
                        div_option_4.onclick=null;
                        clicked_position=this.getAttribute("data-position");
                        if(clicked_position==question.answer)
                        {
                            this.style.background="#5eff5e";
                            score++;
                            attended_questions=attended_questions+1;
                            btn_score.innerHTML=score;
                            correct_ans_audio.play();
                        }
                        else
                        {
                            this.style.background="#ffc08c";
                            document.querySelector("[data-correct=true]").style.background="#5eff5e";
                            attended_questions=attended_questions+1;
                            wrong_ans_audio.play();
                        }
                        
                        questions[question_number-1].u=this.getAttribute("data-position");
                        setTimeout(function(){
                            load_question(current_question+1);
                            div_question_panel.style.opacity=0;
                        },1000);
                    };
                }
                else
                {
                    div_correct_ans.style.background="#5eff5e";
                    var div_user_ans=document.getElementById("div_option_"+question.u);
                    if(div_correct_ans!=div_user_ans)
                    {
                        div_user_ans.style.background="#ffc08c";
                    }
                    div_option_1.onclick=
                    div_option_2.onclick=
                    div_option_3.onclick=
                    div_option_4.onclick=null;
                }
        
            }catch(error){
                alert(error);
                
            }
        }

        function show_score_panel()
        {
            div_total_question.innerHTML=total_questions;
            div_attended_questions.innerHTML=attended_questions;
            div_correct_questions.innerHTML=score;
            div_incorrect_questions.innerHTML = (attended_questions-score);
            percentage = ((score/total_questions)*100);

            

            var className = 'blue';
            if(percentage <= 30) className= 'orange';
            else if(percentage > 60) className = 'green';

            

            div_score_percentage.innerHTML='<div class="single-chart"> <svg viewbox="0 0 36 36" class="circular-chart '+className+'"> <path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/> <path class="circle" stroke-dasharray="'+percentage+', 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"/> <text x="18" y="20.35" class="percentage">'+percentage+'%</text> </svg> </div>';

            div_title_bar.style.display = div_question_panel.style.display='none';
            div_score_panel.style.display='block';
        }
        function hide_score_panel()
        {
            load_question(total_questions);
            div_title_bar.style.display = 'flex';
            div_question_panel.style.display='block';
            div_score_panel.style.display='none';
        }

        function go_to_home()
        {
            if(1 < history.length) 
            {
                history.back();
            }
            else 
            {
                location.href = 'https://rytplays.com/quiz/';
            }
        }