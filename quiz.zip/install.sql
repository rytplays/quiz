-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2021 at 07:42 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rytplays_career`
--

-- --------------------------------------------------------

--
-- Table structure for table `quiz_posts`
--

CREATE TABLE `quiz_posts` (
  `id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `slug` varchar(100) NOT NULL,
  `status` char(1) NOT NULL DEFAULT 'D',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `title` text NOT NULL,
  `thumbnail_url` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL
) 
ENGINE=InnoDB 
DEFAULT CHARSET=utf8mb4
COLLATE = utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_post_tag`
--

CREATE TABLE `quiz_post_tag` (
  `post_id` int UNSIGNED NOT NULL,
  `tag_id` int UNSIGNED NOT NULL
) 
ENGINE=InnoDB 
DEFAULT CHARSET=utf8mb4
COLLATE = utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_questions`
--

CREATE TABLE `quiz_questions` (
  `quiz_post_id` int UNSIGNED NOT NULL,
  `number` smallint(3) UNSIGNED NOT NULL CHECK (`number` >= 1 and `number` <= 999),
  `title` text NOT NULL,
  `option_1` text DEFAULT NULL,
  `option_2` text DEFAULT NULL,
  `option_3` text DEFAULT NULL,
  `option_4` text DEFAULT NULL,
  `answer` tinyint(1) UNSIGNED NOT NULL CHECK (`answer` >= 0 and `answer` <= 4),
  `explaination` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COLLATE = utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quiz_tags`
--

CREATE TABLE `quiz_tags` (
  `id` int UNSIGNED NOT NULL,
  `slug` varchar(100) NOT NULL,
  `name` text DEFAULT NULL,
  `thumbnail_url` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COLLATE = utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int UNSIGNED NOT NULL,
  `email` varchar(60) NOT NULL,
  `password_hash` varchar(60) NOT NULL,
  `remember_key` char(16) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `name` text NOT NULL,
  `about` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `photo_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COLLATE = utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password_hash`, `remember_key`, `enabled`, `name`, `about`, `description`, `photo_url`) VALUES
(1, '16102000.raghu@gmail.com', '$2y$10$MvGzUljDL5W3VcP20yNNL.xgkZB8BFbRkst2vQR5Jpzd9kW/8ZvIa', '8e14af725b0e0736', 0, 'Raghavendra K J', 'B.Sc', NULL, 'https://lh3.googleusercontent.com/ogw/ADGmqu_4j_L9a-xwTZwVJdrxUEJwQbODz5d0swSjjqnm=s192-c-mo');

-- --------------------------------------------------------

--
-- Table structure for table `user_permissions`
--

CREATE TABLE `user_permissions` (
  `user_id` int(11) UNSIGNED NOT NULL,
  `permission` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
COLLATE = utf8mb4_general_ci;

--
-- Dumping data for table `user_permissions`
--

INSERT INTO `user_permissions` (`user_id`, `permission`) VALUES
(1, 'manage-quiz-tags'),
(1, 'manage-quizzes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `quiz_posts`
--
ALTER TABLE `quiz_posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `quiz_posts_ibfk_1` (`user_id`);

--
-- Indexes for table `quiz_post_tag`
--
ALTER TABLE `quiz_post_tag`
  ADD PRIMARY KEY (`post_id`,`tag_id`),
  ADD KEY `quiz_post_tag_ibfk_2` (`tag_id`);

--
-- Indexes for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD PRIMARY KEY (`quiz_post_id`,`number`);

--
-- Indexes for table `quiz_tags`
--
ALTER TABLE `quiz_tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_permissions`
--
ALTER TABLE `user_permissions`
  ADD PRIMARY KEY (`user_id`,`permission`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quiz_posts`
--
ALTER TABLE `quiz_posts`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quiz_tags`
--
ALTER TABLE `quiz_tags`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `quiz_posts`
--
ALTER TABLE `quiz_posts`
  ADD CONSTRAINT `quiz_posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `quiz_post_tag`
--
ALTER TABLE `quiz_post_tag`
  ADD CONSTRAINT `quiz_post_tag_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `quiz_posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `quiz_post_tag_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `quiz_tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `quiz_questions`
--
ALTER TABLE `quiz_questions`
  ADD CONSTRAINT `quiz_questions_ibfk_1` FOREIGN KEY (`quiz_post_id`) REFERENCES `quiz_posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_permissions`
--
ALTER TABLE `user_permissions`
  ADD CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
