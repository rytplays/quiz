function open_drawer(drawer, overlay) {
	drawer.style.display = 'block';
	overlay.style.display = 'block';
	document.documentElement.style.overflow = 'hidden';
}

function close_drawer(drawer, overlay) {
	drawer.style.display = 'none';
	overlay.style.display = 'none';
	document.documentElement.style.overflow = '';
}

function GEBI(id) {
	return document.getElementById(id);
}

function RON() {
	const [entry] = performance.getEntriesByType("navigation");
	if (entry["type"] === "back_forward") location.reload();
}