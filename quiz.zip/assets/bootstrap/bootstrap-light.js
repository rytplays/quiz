function open_navbar(navbar,overlay)
{
    navbar.style.display = 'block';
    overlay.style.display = 'block';
    document.documentElement.style.overflow = 'hidden';
}

function close_navbar(navbar,overlay)
{
    navbar.style.display = 'none';
    overlay.style.display = 'none';
    document.documentElement.style.overflow = '';
}

function GEBI(id)
{
    return document.getElementById(id);
}
