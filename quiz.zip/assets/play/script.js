function GEBI(id) { return document.getElementById(id); }

const
loader = GEBI('loader'),
quiz_panel = GEBI('quiz_panel'),
question_panel = GEBI('question_panel'),
score_panel = GEBI('score_panel'),

btn_prev = GEBI('btn_prev'),
btn_score = GEBI('btn_score'),
btn_number = GEBI('btn_number'),
btn_next = GEBI('btn_next'),

title = GEBI('title'),
option_1 = GEBI('option_1'),
option_2 = GEBI('option_2'),
option_3 = GEBI('option_3'),
option_4 = GEBI('option_4'),

td_total_questions = GEBI('td_total_questions'),
td_attended_questions = GEBI('td_attended_questions'),
td_correct_questions = GEBI('td_correct_questions'),
td_incorrect_questions = GEBI('td_incorrect_questions'),
progress = GEBI('progress');

var
questions = [],
total_questions = 0,
current_question = 1,
score = 0,
attended_questions = 0;


function get_questions()
{
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() 
    {
        if(this.readyState == 4) 
        {
            if(this.status == 200)
            {
                try { var response = JSON.parse(this.responseText); }
                catch( err ) { loader.innerHTML = err; }
                if(typeof(response) == 'object')
                {
                    questions = response.data.questions;
                    total_questions = questions.length;
                    if( total_questions > 0 )
                    {
                        loader.style.display = 'none';
                        quiz_panel.style.display = 'block';
                        load_question(1);
                    }
                    else
                    {
                        loader.innerHTML = 'NO QUESTIONS FOUND';
                    }
                }
                else
                {
                    loader.innerHTML = 'RESPONSE IS NOT A VALID JSON';
                }
            }
            else
            {
                loader.innerHTML = this.statusText;
                console.log(this);
            }
        }
    };
    xhttp.open("POST",base_url+'get-questions', true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send('quiz_post_id='+quiz_post_id);
}

function load_question(question_number)
{
    if( question_number > total_questions )
    {
        show_score_panel();
        return;
    }
    else if( question_number <= 0 )
    {
        audio_wrong.play();
        return;
    }
    else
    {
        window.clearTimeout();
        setTimeout( function() { question_panel.style.opacity = 1; }, 100 );
        current_question = question_number;
        btn_number.innerHTML = current_question + "/" + total_questions;
        
        option_1.style.background = 
        option_2.style.background = 
        option_3.style.background = 
        option_4.style.background = "#FFF";
        
        var question = questions[question_number - 1];
        
        title.innerHTML = question.title;
        
        option_1.innerHTML = question.option_1,
        option_2.innerHTML = question.option_2,
        option_3.innerHTML = question.option_3,
        option_4.innerHTML = question.option_4;
        
        option_1.setAttribute("data-answer",false);
        option_2.setAttribute("data-answer",false);
        option_3.setAttribute("data-answer",false);
        option_4.setAttribute("data-answer",false);

        try
        {
            correct_option = GEBI('option_'+question.answer);
            correct_option.setAttribute('data-answer',true);

            if(question.u == undefined)
            {
                option_1.onclick =
                option_2.onclick =
                option_3.onclick =
                option_4.onclick =
                function()
                {
                    option_1.onclick =
                    option_2.onclick =
                    option_3.onclick =
                    option_4.onclick = null;

                    var clicked_position = this.getAttribute("data-position");
                    if( clicked_position == question.answer )
                    {
                        this.style.background="#5eff5e";
                        score++;
                        attended_questions = attended_questions + 1;
                        btn_score.innerHTML = score;
                        audio_correct.play();
                    }
                    else
                    {
                        this.style.background = "#ffc08c";
                        document.querySelector("[data-answer=true]").style.background = "#5eff5e";
                        attended_questions = attended_questions + 1;
                        audio_wrong.play();
                    }
                    
                    questions[question_number - 1].u = this.getAttribute("data-position");
                    setTimeout(function(){ load_question(current_question + 1);  question_panel.style.opacity = 0; }, 1000);
                };
            }
            else
            {
                correct_option.style.background = "#5eff5e";
                var user_option = GEBI("option_"+question.u);
                if(correct_option != user_option) user_option.style.background="#ffc08c";
                
                option_1.onclick =
                option_2.onclick =
                option_3.onclick =
                option_4.onclick = null;
            }
        }
        catch(e) { alert(e); }
    }
}

function show_score_panel()
{
    td_total_questions.innerHTML = total_questions;
    td_attended_questions.innerHTML = attended_questions;
    td_correct_questions.innerHTML = score;
    td_incorrect_questions.innerHTML = ( attended_questions - score );
    percentage = Math.floor( ( score / total_questions ) * 100 );

    var progressColor = '#00a4f0';
    if(percentage <= 40) progressColor= '#ff9500';
    else if(percentage > 60) progressColor = '#10f000';

    progress.style.backgroundColor = progressColor;
    progress.style.width = progress.innerHTML = percentage + "%"; 

    quiz_panel.style.display = 'none';
    score_panel.style.display = 'block';
}

function hide_score_panel()
{
    load_question(total_questions);
    quiz_panel.style.display='block';
    score_panel.style.display='none';
}

function go_to_home()
{
    (history.length > 1) ? history.back() : location.href = base_url;
}

get_questions();



