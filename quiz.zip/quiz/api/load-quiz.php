<?php
include("core.php");
$quiz_id = $_GET["quiz_id"] ?? null;
if(ctype_digit($quiz_id))
{
    $quiz = $db->get("quizzes",'*',["id"=>$quiz_id]);
    if($quiz!=null)
    {
        if($quiz["status"] == "published")
        {
            $questions = $db->select("questions",'*',['quiz_id'=>$quiz['id'],'answer[>]'=>0]);
            if($questions!=null)
            {
                
                for($i=0;$i<count($questions);$i++)
                {
                    $questions[$i]["u"]=0;
                }
                

                exit_with_response("success","Quiz Fetched Successfully",[
                    "quiz"=>$quiz,
                    "questions"=>$questions,
                ]);
            }
            else
            {
                exit_with_response("error","no questions found");
            }
        }
        else
        {
            exit_with_response("error","quiz not published");
        }
    }
    else
    {
        exit_with_response("error","quiz not exits");
    }
}
else
{
    exit_with_response("error","please include valid quiz id");
}

?>