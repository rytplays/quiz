<?php
require("core.php");
if(REQUEST_METHOD("POST"))
{
    $user_id = POST("user_id");
    $user_api_key = POST("user_api_key");

    if(!ctype_digit($user_id)) exit_with_response("error","invalid user id");
    if(strlen($user_api_key)!=32) exit_with_response("error","invalid api key");

    $user = $db->get("users",["id","api_key","enabled"],["id"=>$user_id]);
    if($user!=null)
    {
        if($user_api_key == $user["api_key"])
        {
            if($user["enabled"])
            {
                $user_role = $db->get("user_roles","*",["user_id"=>$user["id"],"role"=>"quiz_author"]);
                if($user_role!=null)
                {
                    exit_with_response("success","login success");
                }
                else
                {
                    exit_with_response("error","permission denied");
                }
            }
            else
            {
                exit_with_response("error","user disabled");
            }
        }
        else
        {
            exit_with_response("error","invalid API Key");
        }
    }
    else
    {
        exit_with_response("error","user not exists");
    }


}
?>