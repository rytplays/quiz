<?php
require("core.php");
if(REQUEST_METHOD("POST"))
{
    $user_id = POST("user_id");
    $user_api_key = POST("user_api_key");
    if(!ctype_digit($user_id)) exit_with_response("error","Invalid user id");
    if(strlen($user_api_key)!=32) exit_with_response("error","Invalid API Key");

    $quiz_id = POST("quiz_id");
    if(!ctype_digit($quiz_id)) exit_with_response("error","Invalid quiz id");

    $user = $db->get("users","*",["id"=>$user_id]);
    if($user!=null)
    {
        if($user["enabled"])
        {
            if($user["api_key"]==$user_api_key)
            {
                $user_role = $db->get("user_roles","*",["role"=>"quiz_author","user_id"=>$user["id"]]);
                if($user_role!=null)
                {
                    $quiz = $db->get("quizzes","*",["id"=>$quiz_id]);
                    if($quiz!=null)
                    {
                        if($quiz["user_id"]==$user["id"])
                        {
                            $question = sanitise_hst(POST("question"));
                            if(strlen($question)<1) exit_with_response("error","Question is empty");

                            $option_1 = sanitise_hst(POST("option_1"));
                            $option_2 = sanitise_hst(POST("option_2"));
                            $option_3 = sanitise_hst(POST("option_3"));
                            $option_4 = sanitise_hst(POST("option_4"));

                            $answer = POST("answer");
                            if(!ctype_digit($answer) or $answer<0 or $answer>4) exit_with_response("error","Option is invalid");

                            $db->insert("questions",[
                                "quiz_id"=>$quiz["id"],
                                "question"=>$question,
                                "option_1"=>$option_1,
                                "option_2"=>$option_2,
                                "option_3"=>$option_3,
                                "option_4"=>$option_4,
                                "answer"=>$answer,
                            ]);

                            exit_with_response("success","Question Added Successfully",$db->get("questions","*",["id"=>$db->id()]));
                            
                        }
                        else
                        {
                            exit_with_response("error","Quiz not exits");
                        }
                    }
                    else
                    {
                        exit_with_response("error","Quiz not exits");
                    }
                }
                else
                {
                    exit_with_response("error","Permission not availabele");
                }
            }
            else
            {
                exit_with_response("error","Authentication Failed");
            }
        }
        else
        {
            exit_with_response("error","User disabled");
        }
    }
    else
    {
        exit_with_response("error","User not exists");
    }

}
?>