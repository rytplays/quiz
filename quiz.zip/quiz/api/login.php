<?php
require("core.php");
if(REQUEST_METHOD("POST"))
{
    $email = POST("email");
    $password = POST("password");

    if(!empty($email) and !empty($password))
    {
        $user = $db->get("users","*",["email"=>$email]);
        if($user!=null)
        {
            if($user["failed_login_attempts"]<11)
            {
                if($user["enabled"])
                {
                    if(password_verify($password,$user["password_hash"]))
                    {
                        if(strlen($user["api_key"])!=32)
                        {
                            $db->update("users",["api_key"=>(bin2hex(random_bytes(16)))],["id"=>$user["id"],"LIMIT"=>1]);
                        }
                        $db->update("users",["failed_login_attempts"=>0],["id"=>$user["id"],"LIMIT"=>1]);
                        $user = $db->get("users","*",["id"=>$user["id"]]);
                        unset($user["password_hash"]);
                        exit_with_response("success","login success",["user"=>$user]);
                    }
                    else
                    {
                        $db->update("users",["failed_login_attempts"=>($user["failed_login_attempts"]+1)],["id"=>$user["id"],"LIMIT"=>1]);
                        exit_with_response("error","password is incorrect",[
                            "remaining_login_attempts"=>10-$user["failed_login_attempts"]
                        ]);
                    }
                }
                else
                {
                    exit_with_response("error","user disabled");
                }
            }
            else
            {
                exit_with_response("error","login attempts exceed");
            }
        }
        else
        {
            exit_with_response("error","user not exists");
        }
    }
    else
    {
        exit_with_response("error","email or password is empty");
    }

}
?>