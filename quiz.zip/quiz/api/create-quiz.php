<?php
require("core.php");
if(REQUEST_METHOD("POST"))
{
    $user_id = POST("user_id");
    $user_api_key = POST("user_api_key");
    if(!ctype_digit($user_id)) exit_with_response("error","Invalid user id");
    if(strlen($user_api_key)!=32) exit_with_response("error","Invalid API Key");

    

    $user = $db->get("users","*",["id"=>$user_id]);
    if($user!=null)
    {
        if($user["enabled"])
        {
            if($user["api_key"]==$user_api_key)
            {
                $user_role = $db->get("user_roles","*",["role"=>"quiz_author","user_id"=>$user["id"]]);
                if($user_role!=null)
                {
                    $title = sanitise_hst(POST("title"));
                    $status = POST("status");
                    $created_time = POST("created_time");
                    $updated_time = POST("updated_time");
                    $about = sanitise_hst(POST("about"));
                    $description = sanitise_hst(POST("description"));
                    $thumbnail_url = POST("thumbnail_url");

                    if(strlen($title)<1) exit_with_response("error","Title is empty");
                    if($status!="published" and $status!="draft") exit_with_response("error","Status is invalid");
                    if(($created_time=strtotime($created_time))==false) exit_with_response("error","Created Time is invalid");
                    if(($updated_time = strtotime($updated_time))==false) exit_with_response("error","Updated time is invalid");
                    if(strlen($thumbnail_url)>0)
                    {
                        if(($thumbnail_url = filter_var($thumbnail_url,FILTER_VALIDATE_URL))==false)
                        {
                            exit_with_response("error","Invalid Thumbnail URL");
                        }
                    }

                    if($created_time<$updated_time or $created_time == $updated_time)
                    {
                        $created_time = date("Y-m-d H:i:s",$created_time);
                        $updated_time = date("Y-m-d H:i:s",$updated_time);
                    }
                    else
                    {
                        exit_with_response("error","Updated time must be greater than created time");
                    }

                    $db->insert("quizzes",[
                        "user_id"=>$user["id"],
                        "title"=>$title,
                        "status"=>$status,
                        "created_time"=>$created_time,
                        "updated_time"=>$updated_time,
                        "about"=>$about,
                        "description"=>$description,
                        "thumbnail_url"=>$thumbnail_url
                    ]);

                    exit_with_response("success","Quiz created successfully",$db->get("quizzes","*",["id"=>$db->id()]));

                }
                else
                {
                    exit_with_response("error","Permission not availabele");
                }
            }
            else
            {
                exit_with_response("error","Authentication Failed");
            }
        }
        else
        {
            exit_with_response("error","User disabled");
        }
    }
    else
    {
        exit_with_response("error","User not exists");
    }

}
?>