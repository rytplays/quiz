<?php
header("Access-Control-Allow-Origin: *");
use Medoo\Medoo;
require("config.php");
require("medoo.php");


function exit_with_response($type,$msg,$data=null)
{
    exit
    (
        json_encode
        ([
            "type"=>$type,
            "msg"=>$msg,
            "data"=>$data
        ])
    );
}

try
{
    $db = new Medoo([
        'database_type' => 'mysql',
        'database_name' => DB_NAME,
        'server' => DB_HOST,
        'username' => DB_USERNAME,
        'password' => DB_PASSWORD,
        'charset' => DB_CHARSET,
        'collation' => DB_COLLATION,
        'prefix' => DB_PREFIX,
    ]);
}
catch(PDOException $e)
{
    exit_with_response("catch",$e->getMessage());
}

function REQUEST_METHOD($METHOD)
{
    if($_SERVER["REQUEST_METHOD"]==$METHOD)
    {
        return true;
    }
    else
    {
        exit_with_response("error","Request method must be $METHOD");
    }
}

function POST($key)
{
    if(isset($_POST[$key]))
    {
        if(is_string($_POST[$key]))
        {
            return $_POST[$key];
        }
        else
        {
            exit_with_response("error","$key must be string");
        }
    }
    else
    {
        exit_with_response("error","$key not sent through POST request");
    }
}

function GET($key)
{
    if(isset($_GET[$key]))
    {
        if(is_string($_GET[$key]))
        {
            return $_GET[$key];
        }
        else
        {
            exit_with_response("error","$key must be string");
        }
    }
    else
    {
        exit_with_response("error","$key not sent through GET request");
    }
}

function sanitise_hst($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

?>