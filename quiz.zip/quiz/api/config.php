<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'rytplays_quiz');
define('DB_USERNAME', 'rytplays_quiz');
define('DB_PASSWORD', '112600R=r');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATION', 'utf8mb4_unicode_ci');
define('DB_PREFIX', 'rp_');
?>