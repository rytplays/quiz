<?php
require("core.php");
if(REQUEST_METHOD("POST"))
{
    $user_id = POST("user_id");
    $user_api_key = POST("user_api_key");
    if(!ctype_digit($user_id)) exit_with_response("error","Invalid user id");
    if(strlen($user_api_key)!=32) exit_with_response("error","Invalid API Key");

    $page_no = $_POST["page_no"] ?? "1";
    if(!ctype_digit($page_no) or $page_no<1) exit_with_response("error","Invalid page_no");


    $user = $db->get("users","*",["id"=>$user_id]);
    if($user!=null)
    {
        if($user["enabled"])
        {
            if($user["api_key"]==$user_api_key)
            {
                $user_role = $db->get("user_roles","*",["role"=>"quiz_author","user_id"=>$user["id"]]);
                if($user_role!=null)
                {
                    $limit = 10;
                    $where = ["user_id"=>$user["id"]];
                    $total_quizzes = $db->count("quizzes",["id"],$where);
                    $offset = ($page_no-1)*$limit;
                    $total_pages = ceil($total_quizzes/$limit);
                    $where["ORDER"] = ["created_time"=>"DESC","id"=>"DESC"];
                    $where["LIMIT"] = [$offset,$limit];
                    $quizzes = $db->select("quizzes","*",$where);

                    exit_with_response("success","quizzes fetched successfully",[
                        "quizzes"=>$quizzes,
                        "total_pages"=>$total_pages,
                        "total_quizzes"=>$total_quizzes,
                        "page_no"=>$page_no
                    ]);
                }
                else
                {
                    exit_with_response("error","Permission not availabele");
                }
            }
            else
            {
                exit_with_response("error","Authentication Failed");
            }
        }
        else
        {
            exit_with_response("error","User disabled");
        }
    }
    else
    {
        exit_with_response("error","User not exists");
    }

}
?>