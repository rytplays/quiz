<?php
require("core.php");
if(REQUEST_METHOD("POST"))
{
    $user_id = POST("user_id");
    $user_api_key = POST("user_api_key");
    if(!ctype_digit($user_id)) exit_with_response("error","Invalid user id");
    if(strlen($user_api_key)!=32) exit_with_response("error","Invalid API Key");

    $quiz_id = POST("quiz_id");
    if(!ctype_digit($quiz_id)) exit_with_response("error","Invalid quiz id");

    $question_id = POST("question_id");
    if(!ctype_digit($question_id)) exit_with_response("error","Invalid question id");

    $user = $db->get("users","*",["id"=>$user_id]);
    if($user!=null)
    {
        if($user["enabled"])
        {
            if($user["api_key"]==$user_api_key)
            {
                $user_role = $db->get("user_roles","*",["role"=>"quiz_author","user_id"=>$user["id"]]);
                if($user_role!=null)
                {
                    $quiz = $db->get("quizzes",["id","user_id"],["id"=>$quiz_id]);
                    if($quiz!=null)
                    {
                        if($quiz["user_id"]==$user["id"])
                        {
                            $question_in_db = $db->get("questions",["id","quiz_id"],["id"=>$question_id,"quiz_id"=>$quiz["id"]]);
                            if($question_in_db!=null)
                            {
                                $db->delete("questions",["id"=>$question_in_db["id"],"LIMIT"=>1]);
                                exit_with_response("success","Question deleted Successfully",$db->get("questions","*",["id"=>$question_in_db["id"]]));
                            }
                            else
                            {
                                exit_with_response("error","Question not exists");
                            }
                        }
                        else
                        {
                            exit_with_response("error","Quiz not belongs to you");
                        }
                    }
                    else
                    {
                        exit_with_response("error","Quiz not exits");
                    }
                }
                else
                {
                    exit_with_response("error","Permission not availabele");
                }
            }
            else
            {
                exit_with_response("error","Authentication Failed");
            }
        }
        else
        {
            exit_with_response("error","User disabled");
        }
    }
    else
    {
        exit_with_response("error","User not exists");
    }

}
?>