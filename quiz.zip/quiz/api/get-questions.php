<?php
require("core.php");
if(REQUEST_METHOD("POST"))
{
    $user_id = POST("user_id");
    $user_api_key = POST("user_api_key");
    if(!ctype_digit($user_id)) exit_with_response("error","Invalid user id");
    if(strlen($user_api_key)!=32) exit_with_response("error","Invalid API Key");

    $quiz_id = POST("quiz_id");
    if(!ctype_digit($quiz_id)) exit_with_response("error","Invalid quiz id");

    $page_no = $_POST["page_no"] ?? "1";
    if(!ctype_digit($page_no) or $page_no<1) exit_with_response("error","Invalid page_no");


    $user = $db->get("users","*",["id"=>$user_id]);
    if($user!=null)
    {
        if($user["enabled"])
        {
            if($user["api_key"]==$user_api_key)
            {
                $user_role = $db->get("user_roles","*",["role"=>"quiz_author","user_id"=>$user["id"]]);
                if($user_role!=null)
                {
                    $quiz = $db->get("quizzes",["id","user_id"],["id"=>$quiz_id]);
                    if($quiz!=null)
                    {
                        if($quiz["user_id"]==$user["id"])
                        {
                            $limit = 5;
                            $where = ["quiz_id"=>$quiz["id"]];
                            $total_questions = $db->count("questions",["id"],$where);
                            $offset = ($page_no-1)*$limit;
                            $total_pages = ceil($total_questions/$limit);

                            $order_by = $_POST["order_by"] ?? "DESC";
                            if(!is_string($order_by)) exit_with_response("error","order_by must string");
                            if($order_by==="ASC")
                            {
                                $order_by =  "ASC";
                            }
                            else
                            {
                                $order_by =  "DESC"; 
                            }

                            $where["ORDER"] = ["id"=>$order_by];
                            $where["LIMIT"] = [$offset,$limit];
                            $questions = $db->select("questions","*",$where);

                            exit_with_response("success","questions fetched successfully",[
                                "questions"=>$questions,
                                "total_pages"=>$total_pages,
                                "total_questions"=>$total_questions,
                                "page_no"=>$page_no
                            ]);
                        }
                        else
                        {
                            exit_with_response("error","Quiz not belongs to you");
                        }
                    }
                    else
                    {
                        exit_with_response("error","Quiz not exits");
                    }
                }
                else
                {
                    exit_with_response("error","Permission not availabele");
                }
            }
            else
            {
                exit_with_response("error","Authentication Failed");
            }
        }
        else
        {
            exit_with_response("error","User disabled");
        }
    }
    else
    {
        exit_with_response("error","User not exists");
    }

}
?>