<?php $version =1; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link rel="stylesheet" href="res/css/style.css?v=<?php echo $version; ?>">
    <link rel="stylesheet" href="res/icons/style.css?v=<?php echo $version; ?>">
    <script src="res/js/core.js?v=<?php echo $version; ?>"></script>
</head>
<body>

