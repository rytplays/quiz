<?php include("inc/header.php"); ?>


<div class="p-3">
    <form id="login_form" class="p-3 shadow-sm border">
        <div>
            <label for="input_email" class="form-label">Email</label>
            <input type="text" class="form-control" autocomplete="off" id="input_email">
        </div>
        <div class="mt-3">
            <label for="input_password" class="form-label">Password</label>
            <input type="text" class="form-control" autocomplete="off" id="input_password">
        </div>
        <button type="submit" class="btn btn-primary mt-3">LOGIN</button>
    </form>
</div>


<?php include("inc/scripts.php"); ?>

<script src="res/js/login.js?v=<?php echo $version; ?>"></script>

<?php include("inc/footer.php"); ?>

