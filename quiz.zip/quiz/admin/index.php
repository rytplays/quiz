<?php include("inc/header.php"); ?>

<div class="p-1 shadow-sm d-flex justify-content-between">
    <a class="btn btn-primary btn-sm ic ic-add" href="create-quiz.php"></a>
    <div><b>MY QUIZZES</b></div>
    <button onclick="load_quizzes();" class="ic ic-refresh btn btn-primary btn-sm"></button>
</div>

<div id="quizzes_container" class="d-none">

    <div id="quizzes" class="container-fluid py-2">

        <div w3-repeat='quizzes' class="shadow-sm border mb-2">
            <div id = quiz_title_{{id}} class="p-2 border-bottom">{{title}}</div>
            <div data-quiz-id={{id}} class="d-flex justify-content-between p-2">
                <a href="manage-questions.php?quiz_id={{id}}" class="btn btn-outline-primary ic ic-apps"></a>
                <a target="_blank" href="update-quiz.php?id={{id}}" class="btn btn-outline-secondary ic ic-create"></a>
                <a onclick="delete_quiz(this)" class="btn btn-outline-danger ic ic-delete"></a>
            </div>
        </div>

    </div>

    <div class="d-flex justify-content-center my-5">
        <div id="pagination" class="btn-group">
            <button onclick="prev()" id="btn_prev" class="btn btn-primary">PREV</button>
            <button onclick="next()" id="btn_next" class="btn btn-primary">NEXT</button>
        </div>
    </div>

</div>


<?php include("inc/scripts.php"); ?>

<script src="res/js/w3.js"></script>

<script src="res/js/index.js?v=<?php echo $version; ?>"></script>

<?php include("inc/footer.php"); ?>