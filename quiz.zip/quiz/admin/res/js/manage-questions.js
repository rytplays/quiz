const 
quiz_title = GEBI('quiz_title'),
body_content = GEBI('body_content'),
questions_list = GEBI('questions_list');

function update_question_to_ui(question_text,id)
{
    GEBI("question_title_"+id).innerHTML = question_text;
}

function add_question_to_ui(question_text,id)
{
    var divP = document.createElement("div");
    divP.setAttribute("class","shadow-sm border mb-2");
    divP.setAttribute("id","question_"+id);


    var divT = document.createElement("div");
    divT.setAttribute("class","p-2 border-bottom");
    divT.setAttribute("id","question_title_"+id);
    divT.innerHTML = question_text;


    var divB = document.createElement("div");
    divB.setAttribute("class","d-flex justify-content-between p-2");
    divB.setAttribute("data-question-id",id);

    var aEdit= document.createElement('a');
    aEdit.setAttribute("class","btn btn-sm btn-outline-primary ic ic-create");
    aEdit.onclick = function(){ view_edit_question_dialog(id); }

    var aDelete= document.createElement('a');
    aDelete.setAttribute("class","btn btn-sm btn-outline-danger ic ic-delete");
    aDelete.onclick = function(){ view_delete_question_dialog(id); }

    divP.appendChild(divT);
    divP.appendChild(divB);

    divB.appendChild(aEdit);
    divB.appendChild(aDelete);
    
    questions_list.appendChild(divP);
}


function remove_question_from_ui(id)
{
    var divP = GEBI("question_"+id);
    divP.remove();
}


function disabledWindow()
{
    document.addEventListener("click",windowDisabler,true);
}

function enableWindow()
{
    document.removeEventListener("click",windowDisabler,true);
}

function windowDisabler(e)
{
    e.stopPropagation();
    e.preventDefault();
    return false;
}





const c_form = GEBI('c_form'),
c_ta_qu = GEBI('c_ta_qu'),
c_ta_o1 = GEBI('c_ta_o1'),
c_ta_o2 = GEBI('c_ta_o2'),
c_ta_o3 = GEBI('c_ta_o3'),
c_ta_o4 = GEBI('c_ta_o4'),
c_in_ans= GEBI('c_in_ans');
c_btn_submit = GEBI('c_btn_submit');
const quiz_id = getURLParameter('quiz_id');



var lDialog = new dialog();
function load_all_questions()
{
    body_content.setAttribute("class","d-none");
    lDialog.loading();
    $.post
    ({
        url : api_url + "get-all-questions.php",
        data : 
        {
            user_id : user_id,
            user_api_key : user_api_key,
            quiz_id : quiz_id,
            order_by : "ASC",
        }
    })
    .done(function(response)
    {
        try
        {
            response = JSON.parse(response);
            if(response.type == "success")
            {
                var loaded_questions = response.data.questions;
                questions_list.textContent = '';
                for(var i = 0;i<loaded_questions.length;i++)
                {
                    add_question_to_ui(loaded_questions[i].question,loaded_questions[i].id);
                }
                lDialog.hide();
                console.log(response);
                quiz_title.innerHTML = response.data.quiz_title;
                body_content.setAttribute("class","d-block");
            }
            else
            {
                alert(response.type+"\n"+response.msg);
                console.log(response);
            }
        }
        catch(error)
        {
            alert(error);
            console.log(error);
            console.log(response);
        }
    })
    .fail(function(error)
    {
        alert(error);
        console.log(error);
    });
}



if(typeof(quiz_id)=='string' && quiz_id>0) 
{

    load_all_questions();
}
else{location.href = 'index.php';}


c_form.addEventListener('submit',function(event)
{
    event.preventDefault();
    disabledWindow();
    c_btn_submit.disabled = true;
    c_btn_submit.innerHTML = "Please Wait";

    $.post
    ({
        url : api_url + "create-question.php",
        data : 
        {
            user_id : user_id,
            user_api_key : user_api_key,
            quiz_id : quiz_id,
            question : c_ta_qu.value,
            option_1 : c_ta_o1.value,
            option_2 : c_ta_o2.value,
            option_3 : c_ta_o3.value,
            option_4 : c_ta_o4.value,
            answer : c_in_ans.value
        }
    })
    .done(function(response)
    {
        try
        {
            response = JSON.parse(response);
            if(response.type == "success")
            {
                add_question_to_ui(response.data.question,response.data.id);
                if(confirm("Question Added. Do You want to reset form"))
                {
                    c_form.reset();
                }
            }
            else
            {
                alert(response.type + "\n" +response.msg);
            }
            enableWindow();
            c_btn_submit.disabled = false;
            c_btn_submit.innerHTML = "Save";
        }
        catch(error)
        {
            alert(error);
            console.log(error);
            console.log(response);
        }
    }).fail(function(error)
    {
        alert(error);
        console.log(error);
    });

    
});




const u_form = GEBI('u_form'),
u_in_qi= GEBI('u_in_qi');
u_ta_qu = GEBI('u_ta_qu'),
u_ta_o1 = GEBI('u_ta_o1'),
u_ta_o2 = GEBI('u_ta_o2'),
u_ta_o3 = GEBI('u_ta_o3'),
u_ta_o4 = GEBI('u_ta_o4'),
u_in_ans= GEBI('u_in_ans');
u_btn_submit = GEBI('u_btn_submit');

var u_modal = new bootstrap.Modal(document.getElementById('u_modal'), 
{
    keyboard: false,
});

var sqlDialog = new dialog();
function view_edit_question_dialog(question_id)
{
    sqlDialog.loading();
    
    $.post
    ({
        url : api_url + "get-question.php",
        data : 
        {
            user_id : user_id,
            user_api_key : user_api_key,
            quiz_id : quiz_id,
            question_id : question_id
        }
    })
    .done(function(response)
    {
        try
        {
            response = JSON.parse(response);
            if(response.type == "success")
            {
                var loaded_question = response.data;

                u_in_qi.value = loaded_question.id;
                u_ta_qu.value = loaded_question.question;

                u_ta_o1.value = loaded_question.option_1;
                u_ta_o2.value = loaded_question.option_2;
                u_ta_o3.value = loaded_question.option_3;
                u_ta_o4.value = loaded_question.option_4;

                u_in_ans.value = loaded_question.answer;
                
                u_modal.show();
                sqlDialog.hide();

            }
            else
            {
                alert(response.type+"\n"+response.msg);
                console.log(response);
                sqlDialog.hide();
            }
        }
        catch(error)
        {
            alert(error);
            console.log(error);
            console.log(response);
            sqlDialog.hide();
        }
        
    })
    .fail(function(error)
    {
        alert(error);
        console.log(error);
    });

}


u_form.addEventListener('submit',function(event)
{
    event.preventDefault();
    disabledWindow();
    u_btn_submit.disabled = true;
    u_btn_submit.innerHTML = "Please Wait";



    $.post
    ({
        url : api_url + "update-question.php",
        data : 
        {
            user_id : user_id,
            user_api_key : user_api_key,
            quiz_id : quiz_id,
            question_id : u_in_qi.value,
            question : u_ta_qu.value,
            option_1 : u_ta_o1.value,
            option_2 : u_ta_o2.value,
            option_3 : u_ta_o3.value,
            option_4 : u_ta_o4.value,
            answer : u_in_ans.value

        }
    })
    .done(function(response)
    {
        try
        {
            response = JSON.parse(response);
            if(response.type == "success")
            {
                update_question_to_ui(response.data.question,response.data.id);
                u_modal.hide();
            }
            enableWindow();
            u_btn_submit.disabled = false;
            u_btn_submit.innerHTML = "Save";
            alert(response.type + "\n" +response.msg);
        }
        catch(error)
        {
            alert(error);
            console.log(error);
            console.log(response);
        }
    }).fail(function(error)
    {
        alert(error);
        console.log(error);
    });

    
});



var dlDialog = new dialog();
function view_delete_question_dialog(question_id)
{
    if(confirm("Are You Sure to delete !\n\n"+GEBI('question_title_'+question_id).innerHTML))
    {   
        dlDialog.loading();
        $.post
        ({
            url : api_url + "delete-question.php",
            data : 
            {
                user_id : user_id,
                user_api_key : user_api_key,
                quiz_id : quiz_id,
                question_id : question_id,
            }
        })
        .done(function(response)
        {
            try
            {
                response = JSON.parse(response);
                if(response.type == "success")
                {
                    remove_question_from_ui(question_id);
                }
                dlDialog.setContent(response.type,response.msg);
                dlDialog.setBtn2();
                dlDialog.setBtn1("OK","btn btn-primary",function(){
                    dlDialog.hide();
                });
                dlDialog.show();
            }
            catch(error)
            {
                alert(error);
                console.log(error);
                console.log(response);
            }
        }).fail(function(error)
        {
            alert(error);
            console.log(error);
        });
    }
}