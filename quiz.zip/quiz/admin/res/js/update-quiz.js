const 
quiz_form_container = GEBI('quiz_form_container'),
form_create_quiz = GEBI('form_create_quiz'),
textarea_title = GEBI('textarea_title'),
input_created_time = GEBI('input_created_time'),
input_updated_time = GEBI('input_updated_time'),
textarea_about = GEBI('textarea_about'),
textarea_description = GEBI('textarea_description'),
input_thumbnail_url = GEBI('input_thumbnail_url'),
checkbox_status = GEBI('checkbox_status');

const quiz_id = getURLParameter('id');


var gDialog = new dialog()
if(typeof(quiz_id)=='string')
{
    gDialog.loading();
    //////

    $.ajax
    ({
        method : "POST",
        url : api_url+"get-quiz.php",
        data : 
        {
            user_id : user_id,
            user_api_key :user_api_key,
            quiz_id : quiz_id,
        }
    })
    .done(function(response)
    {
        try
        {
            response = JSON.parse(response);
        }
        catch (error)
        {
            console.log(response);
            gDialog.setContent("Failed To Parse the JSON", error); 
            gDialog.setBtn2();
            gDialog.setBtn1("OK", "btn btn-secondary", function()
            {
                gDialog.hide();
            });
            gDialog.show();
        }

        if (typeof(response) == "object")
        {
            if (response.type == "success")
            {
                console.log(response.data);

                var mQuestion = response.data;

                textarea_title.value = mQuestion.title;
                input_created_time.value = mQuestion.created_time;
                input_updated_time.value = mQuestion.updated_time;
                textarea_about.value = mQuestion.about;
                textarea_description.value = mQuestion.description;
                input_thumbnail_url.value = mQuestion.thumbnail_url;
                checkbox_status.checked = (mQuestion.status == 'published') ? true : false;


                quiz_form_container.setAttribute("class","d-block");

                
                gDialog.hide();
                
                
            }
            else
            {
                gDialog.setBtn1("OK", "btn btn-secondary", function()
                {
                    gDialog.hide();
                });
                gDialog.setContent(response.type, response.msg);
                gDialog.setBtn2();
                gDialog.show();
            }
            
        }
        else
        {
            console.log(response);
            gDialog.setContent("Something went wrong", 'please see the console for more details');
            gDialog.setBtn2();
            gDialog.setBtn1("OK", "btn btn-secondary", function()
            {
                gDialog.hide()
            });
            gDialog.show();
        }


    })
    .fail(function(error)
    {
        mDialog.setContent("Something went wrong", error);
        mDialog.setBtn2();
        mDialog.setBtn1("OK", "btn btn-secondary", function()
        {
            mDialog.hide();
        });
        mDialog.show();
    });


    /////////

}
else
{
    location.href = 'index.php';
}

/////////////////////////////////////////////////

var mDialog = new dialog();
form_update_quiz.addEventListener('submit',function(event)
{
    event.preventDefault();
    mDialog.loading();

    if(input_created_time.value == '') input_created_time.value = 'now';
    if(input_updated_time.value == '') input_updated_time.value = 'now';

    $.ajax
    ({
        method : "POST",
        url : api_url+"update-quiz.php",
        data : 
        {
            user_id : user_id,
            user_api_key :user_api_key,
            quiz_id : quiz_id,
            title : textarea_title.value,
            status : (checkbox_status.checked == true) ? 'published' : 'draft',
            created_time : input_created_time.value,
            updated_time : input_updated_time.value,
            about : textarea_about.value,
            description : textarea_description.value,
            thumbnail_url : input_thumbnail_url.value,
        }
    })
    .done(function(response)
    {
        try
        {
            response = JSON.parse(response);
        }
        catch (error)
        {
            mDialog.setContent("Failed To Parse the JSON", error); 
            console.log(response);
            mDialog.setBtn2();
            mDialog.setBtn1("OK", "btn btn-secondary", function()
            {
                mDialog.hide();
            });
            mDialog.show();
        }

        if (typeof(response) == "object")
        {
            if (response.type == "success")
            {
                mDialog.setBtn1("GO TO HOME", "btn btn-success", function()
                {
                    window.close();
                });
                mDialog.setBtn2("STAY HERE", "btn btn-primary", function()
                {
                    mDialog.hide();
                });

            }
            else
            {
                mDialog.setBtn1("OK", "btn btn-secondary", function()
                {
                    mDialog.hide();
                });
                mDialog.setBtn2();
            }
            mDialog.setContent(response.type, response.msg);
            mDialog.show();
        }
        else
        {
            console.log(response);
            mDialog.setContent("Something went wrong", 'please see the console for more details');
            mDialog.setBtn2();
            mDialog.setBtn1("OK", "btn btn-secondary", function()
            {
                mDialog.hide()
            });
            mDialog.show();
        }


    })
    .fail(function(error)
    {
        mDialog.setContent("Something went wrong", error);
        mDialog.setBtn2();
        mDialog.setBtn1("OK", "btn btn-secondary", function()
        {
            mDialog.hide();
        });
        mDialog.show();
    });
});