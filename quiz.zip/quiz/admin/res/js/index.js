const quizzes_container = GEBI('quizzes_container');
const btn_prev = GEBI('btn_prev');
const btn_next = GEBI('btn_next');

var qlDialog = new dialog();
qlDialog.header.setAttribute("class","modal-header h5 text-uppercase");

var current_page_no = 1;
function load_quizzes(page_no = current_page_no)
{
    quizzes_container.setAttribute("class","d-none");
    qlDialog.loading();
    $.ajax(
        {
            method: "POST",
            url: api_url + "get-quizzes.php",
            data:
            {
                user_id: user_id,
                user_api_key: user_api_key,
                page_no : page_no,
            }
        })
        .done(function(response)
        {
            try
            {
                response = JSON.parse(response);
            }
            catch (error)
            {
                qlDialog.setContent("Failed To Parse the JSON", error); 
                console.log(response);
                qlDialog.setBtn2();
                qlDialog.setBtn1("OK", "btn btn-secondary", function()
                {
                    qlDialog.hide()
                });
                qlDialog.show();
            }
            if (typeof(response) == "object")
            {
                if (response.type == "success")
                {
                    current_page_no = page_no;

                    btn_prev.disabled = (page_no == 1) ? true : false;
                    btn_next.disabled = (page_no == response.data.total_pages) ? true : false;

                    w3.displayObject("quizzes", response.data);
                    qlDialog.hide();
                    if(response.data.quizzes.length>0)
                    {
                        quizzes_container.setAttribute("class","d-block");
                    }
                    else
                    {
                        if(response.data.total_pages==1 && current_page_no !=1)
                        {
                            load_quizzes();
                        }
                    }

                }
                else
                {
                    qlDialog.setBtn1("OK", "btn btn-secondary", function()
                    {
                        qlDialog.hide()
                    });
                    qlDialog.setContent(response.type, response.msg);
                    qlDialog.setBtn2();
                    qlDialog.show();
                }

            }
            else
            {
                console.log(response);
                qlDialog.setContent("Something went wrong", 'please see the console for more details');
                qlDialog.setBtn2();
                qlDialog.setBtn1("OK", "btn btn-secondary", function()
                {
                    qlDialog.hide()
                });
                qlDialog.show();
            }
        })
        .fail(function(error)
        {
            qlDialog.setContent("Something went wrong", error);
            qlDialog.setBtn2();
            qlDialog.setBtn1("OK", "btn btn-secondary", function()
            {
                qlDialog.hide()
            });
            qlDialog.show();
        });
}

function prev(){
    load_quizzes(current_page_no-1);
}

function next(){
    load_quizzes(current_page_no+1);
}


var qdDialog = new dialog();
function delete_quiz(e)
{
    var quiz_id = e.parentElement.getAttribute('data-quiz-id');

    if(confirm("Are you sure to delete !\n"+GEBI('quiz_title_'+quiz_id).innerHTML ))
    {
        qdDialog.loading();
        $.ajax(
            {
                method: "POST",
                url: api_url + "delete-quiz.php",
                data:
                {
                    user_id: user_id,
                    user_api_key: user_api_key,
                    quiz_id : quiz_id
                }
            })
            .done(function(response)
            {
                try
                {
                    response = JSON.parse(response);
                }
                catch (error)
                {
                    qdDialog.setContent("Failed To Parse the JSON", error); 
                    console.log(response);
                    qdDialog.setBtn2();
                    qdDialog.setBtn1("OK", "btn btn-secondary", function()
                    {
                        qdDialog.hide()
                    });
                    qdDialog.show();
                }
                if(typeof(response) == "object")
                {
                    if (response.type == "success")
                    {
                        qdDialog.setBtn1("REFRESH QUIZZES", "btn btn-secondary", function()
                        {
                            load_quizzes(current_page_no);
                            qdDialog.hide()
                        });
                        qdDialog.setContent("Done", response.msg);
                        qdDialog.setBtn2();
                        qdDialog.show();
                    }
                    else
                    {
                        qdDialog.setBtn1("OK", "btn btn-secondary", function()
                        {
                            qdDialog.hide()
                        });
                        qdDialog.setContent(response.type, response.msg);
                        qdDialog.setBtn2();
                        qdDialog.show();
                    }
                }

            })
            .fail(function(error)
            {
                qlDialog.setContent("Something went wrong", error);
                qlDialog.setBtn2();
                qlDialog.setBtn1("OK", "btn btn-secondary", function()
                {
                    qlDialog.hide()
                });
                qlDialog.show();
            });

    }
}

load_quizzes();