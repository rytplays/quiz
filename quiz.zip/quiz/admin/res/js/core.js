const admin_url ="https://rytplays.com/quiz/admin/";
const api_url ="https://rytplays.com/quiz/api/";

var
user_id = get_cookie('user_id'),
user_api_key = get_cookie('user_api_key');

if(user_id == null || user_api_key == null)
{
    if(window.location.href != admin_url+"login.php")
    {
        location.href = admin_url+"login.php";
    }
}

function get_cookie(name) {
    var v = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
    return v ? v[2] : null;
}

function set_cookie(name, value, days=1) {
    var d = new Date;
    d.setTime(d.getTime() + 24*60*60*1000*days);
    document.cookie = name + "=" + value + ";path=/;expires=" + d.toGMTString();
}

function delete_cookie(name) { set_cookie(name, '', -1); }

function GEBI(id){return document.getElementById(id);}

function getURLParameter(name, url = window.location.href) 
{
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}


