const 
form_create_quiz = GEBI('form_create_quiz'),
textarea_title = GEBI('textarea_title'),
input_created_time = GEBI('input_created_time'),
input_updated_time = GEBI('input_updated_time'),
textarea_about = GEBI('textarea_about'),
textarea_description = GEBI('textarea_description'),
input_thumbnail_url = GEBI('input_thumbnail_url'),
checkbox_status = GEBI('checkbox_status');

var mDialog = new dialog();
form_create_quiz.addEventListener('submit',function(event)
{
    event.preventDefault();
    mDialog.loading();

    if(input_created_time.value == '') input_created_time.value = 'now';
    if(input_updated_time.value == '') input_updated_time.value = 'now';

    $.ajax
    ({
        method : "POST",
        url : api_url+"create-quiz.php",
        data : 
        {
            user_id : user_id,
            user_api_key :user_api_key,
            title : textarea_title.value,
            status : (checkbox_status.checked == true) ? 'published' : 'draft',
            created_time : input_created_time.value,
            updated_time : input_updated_time.value,
            about : textarea_about.value,
            description : textarea_description.value,
            thumbnail_url : input_thumbnail_url.value,
        }
    })
    .done(function(response)
    {
        try
        {
            response = JSON.parse(response);
        }
        catch (error)
        {
            mDialog.setContent("Failed To Parse the JSON", error); 
            console.log(response);
            mDialog.setBtn2();
            mDialog.setBtn1("OK", "btn btn-secondary", function()
            {
                mDialog.hide();
            });
            mDialog.show();
        }

        if (typeof(response) == "object")
        {
            if (response.type == "success")
            {
                mDialog.setBtn1("GO TO HOME", "btn btn-success", function()
                {
                    mDialog.hide();
                    location.href = "index.php";
                });
            }
            else
            {
                mDialog.setBtn1("OK", "btn btn-secondary", function()
                {
                    mDialog.hide();
                });
            }
            mDialog.setContent(response.type, response.msg);
            mDialog.setBtn2();
            mDialog.show();
        }
        else
        {
            console.log(response);
            mDialog.setContent("Something went wrong", 'please see the console for more details');
            mDialog.setBtn2();
            mDialog.setBtn1("OK", "btn btn-secondary", function()
            {
                mDialog.hide()
            });
            mDialog.show();
        }


    })
    .fail(function(error)
    {
        mDialog.setContent("Something went wrong", error);
        mDialog.setBtn2();
        mDialog.setBtn1("OK", "btn btn-secondary", function()
        {
            mDialog.hide();
        });
        mDialog.show();
    });
});