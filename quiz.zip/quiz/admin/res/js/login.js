const form_login = GEBI('login_form');
const input_email = GEBI('input_email');
const input_password = GEBI('input_password');

var loginDialog = new dialog();

delete_cookie('user_id');
delete_cookie('user_api_key');

form_login.addEventListener('submit', function(event)
{
    event.preventDefault();
    loginDialog.loading();

    $.ajax(
        {
            method: "POST",
            url: api_url + "login.php",
            data:
            {
                email: input_email.value,
                password: input_password.value,
            }
        })
        .done(function(response)
        {
            try
            {
                response = JSON.parse(response);
            }
            catch (error)
            {
                loginDialog.setContent("Failed To Parse the JSON", error); 
                console.log(response);
                loginDialog.setBtn2();
                loginDialog.setBtn1("OK", "btn btn-secondary", function()
                {
                    loginDialog.hide()
                });
                loginDialog.show();
            }
            if (typeof(response) == "object")
            {
                if (response.type == "success")
                {
                    set_cookie('user_id', response.data.user.id, 1);
                    set_cookie('user_api_key', response.data.user.api_key, 1);
                    loginDialog.setBtn1("GO TO HOME", "btn btn-success", function()
                    {
                        location.href = "index.php";
                    });

                }
                else
                {
                    loginDialog.setBtn1("OK", "btn btn-secondary", function()
                    {
                        loginDialog.hide()
                    });
                }
                loginDialog.setContent(response.type, response.msg);
                loginDialog.setBtn2();
                loginDialog.show();
            }
            else
            {
                console.log(response);
                loginDialog.setContent("Something went wrong", 'please see the console for more details');
                loginDialog.setBtn2();
                loginDialog.setBtn1("OK", "btn btn-secondary", function()
                {
                    loginDialog.hide()
                });
                loginDialog.show();
            }
        })
        .fail(function(error)
        {
            loginDialog.setContent("Something went wrong", error);
            loginDialog.setBtn2();
            loginDialog.setBtn1("OK", "btn btn-secondary", function()
            {
                loginDialog.hide();
            });
            loginDialog.show();
        });

});