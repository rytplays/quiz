<?php include("inc/header.php"); ?>




<div id="body_content" class="d-none">
<!---->

<div class="shadow-sm position-sticky top-0 bg-white shadow-sm p-1 d-flex justify-content-between">
    <button data-bs-toggle="modal" data-bs-target="#c_modal" class="btn btn-primary ic ic-add btn-sm"></button>
    <div class="p-1 panel-heading" id="quiz_title">QUESTIONS</div>
    <button onclick="load_all_questions();" class="btn btn-primary ic ic-refresh btn-sm"></button>
</div>

<div class="modal" id="c_modal">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
            <form id="c_form">
                <div class="d-flex justify-content-between p-1 border-bottom shadow-sm">
                    <button class="btn btn-danger btn-sm" data-bs-dismiss="modal">CLOSE</button>
                    <button type="reset" class="btn btn-secondary btn-sm">RESET</button>
                    <button id="c_btn_submit" type="submit" class="btn btn-primary btn-sm">SAVE</button>
                </div>
                <div class="modal-body">
                    <textarea required id="c_ta_qu" rows="3" class="form-control r0" placeholder="Question"></textarea>
                    <textarea id="c_ta_o1" rows="1" class="form-control r0" placeholder="Option 1"></textarea>
                    <textarea id="c_ta_o2" rows="1" class="form-control r0" placeholder="Option 2"></textarea>
                    <textarea id="c_ta_o3" rows="1" class="form-control r0" placeholder="Option 3"></textarea>
                    <textarea id="c_ta_o4" rows="1" class="form-control r0" placeholder="Option 4"></textarea>
                    <input required type="number" id="c_in_ans" class="form-control r0" placeholder="Answer" max="4" min="0">
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal" id="u_modal">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
            <form id="u_form">
                <div class="d-flex justify-content-between p-1 border-bottom shadow-sm">
                    <button class="btn btn-danger btn-sm" data-bs-dismiss="modal">CLOSE</button>
                    <button type="reset" class="btn btn-secondary btn-sm">RESET</button>
                    <button id="u_btn_submit" type="submit" class="btn btn-primary btn-sm">SAVE</button>
                </div>
                <div class="modal-body">
                    <input required type="number" id="u_in_qi" class="form-control r0" placeholder="Question ID" min="0" disabled>
                    <textarea required id="u_ta_qu" rows="3" class="form-control r0" placeholder="Question"></textarea>
                    <textarea id="u_ta_o1" rows="1" class="form-control r0" placeholder="Option 1"></textarea>
                    <textarea id="u_ta_o2" rows="1" class="form-control r0" placeholder="Option 2"></textarea>
                    <textarea id="u_ta_o3" rows="1" class="form-control r0" placeholder="Option 3"></textarea>
                    <textarea id="u_ta_o4" rows="1" class="form-control r0" placeholder="Option 4"></textarea>
                    <input required type="number" id="u_in_ans" class="form-control r0" placeholder="Answer" max="4" min="0">
                </div>
            </form>
        </div>
    </div>
</div>



<div id="questions_container" class="">
    <div id="questions_list" class="p-2">
    </div>
</div>


<!---->
</div>





<?php include("inc/scripts.php"); ?>

<script src="res/js/manage-questions.js?v=<?php echo $version; ?>"></script>

<?php include("inc/footer.php"); ?>