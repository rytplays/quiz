<?php include("inc/header.php"); ?>


<div class="p-3">
    <form id="form_create_quiz" class="p-3 shadow-sm border">
        
        <div class="mb-3">
            <label for="textarea_title" class="form-label">Title</label>
            <textarea id="textarea_title" rows="1" class="form-control"></textarea>
        </div>

        <div class="mb-3">
            <label for="input_created_time" class="form-label">Created Time</label>
            <input id="input_created_time" type="text" autocomplete="off" class="form-control">
        </div>

        <div class="mb-3">
            <label for="input_updated_time" class="form-label">Updated Time</label>
            <input id="input_updated_time" type="text" autocomplete="off" class="form-control">
        </div>

        <div class="mb-3">
            <label for="textarea_about" class="form-label">About</label>
            <textarea id="textarea_about" rows="1" class="form-control"></textarea>
        </div>

        <div class="mb-3">
            <label for="textarea_description" class="form-label">Description</label>
            <textarea id="textarea_description" rows="3" class="form-control"></textarea>
        </div>

        <div class="mb-3">
            <label for="input_thumbnail_url" class="form-label">Thumbnail URL</label>
            <input id="input_thumbnail_url" type="text" autocomplete="off" class="form-control">
        </div>

        <div class="form-check mb-3 user-select-none">
            <input class="form-check-input" type="checkbox" value="" id="checkbox_status">
            <label class="form-check-label" for="checkbox_status">
                Publish
            </label>
        </div>

        <button type="submit" class="mt-3 btn btn-primary">SAVE</button>
        
    </form>
</div>


<?php include("inc/scripts.php"); ?>

<script src="res/js/create-quiz.js?v=<?php echo $version; ?>"></script>

<?php include("inc/footer.php"); ?>

