<?php
function get_header($data = []) { ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $data['title_tag'] ?? ''; ?></title>
        <link rel="stylesheet" href="<?= asset_url('bootstrap/bootstrap.css'); ?>">
        <link rel="stylesheet" href="<?= asset_url('bootstrap/bootstrap-plus.css'); ?>">
        <link rel="stylesheet" href="<?= asset_url('icons/icomoon/style.css'); ?>">
        <?= $data['styles'] ?? ''; ?>
        <script src="<?= asset_url('bootstrap/bootstrap.js'); ?>"></script>
        <script src="<?= asset_url('bootstrap/bootstrap-plus.js'); ?>"></script>
        <script src="<?= asset_url('bootstrap/dialog.js'); ?>"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <?= $data['scripts'] ?? ''; ?>
    </head>
    <body class="<?= $data['body_class'] ?? 'bg-solitude'; ?>" >
<?php }

function get_footer() { ?>
    </body>
    </html>
<?php }

function get_drawer($data = [])
{?>

    <div onclick="open_drawer(drawer_left,overlay_left);" class="btn"><b class="ic ic-menu"></b></div>

    <div class="drawer-overlay" id="overlay_left" onclick="close_drawer(drawer_left,overlay_left);"></div>
    
    <nav class="drawer user-select-none" id="drawer_left" style="left: 0;">
        <div class="drawer-header">
            <div class="drawer-brand">MENU</div>
            <div onclick="close_drawer(drawer_left,overlay_left);" class="btn"><b class="ic ic-close"></b></div>
        </div>
        <div class="drawer-links">
            <?php require(view($data['left_drawer_links'])); ?>
        </div>
    </nav>

    <script type="text/javascript">
        const 
        drawer_left = GEBI('drawer_left'),
        overlay_left = GEBI('overlay_left');
    </script>

<?php } ?>


    
