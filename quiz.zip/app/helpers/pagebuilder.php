<?php
function get_header($data = []) { ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $data['title_tag'] ?? ''; ?></title>
        <meta name="description" content="<?= $data['description_tag'] ?? ''; ?>">

        <link rel="stylesheet" href="<?= asset_url('fonts/lato.css'); ?>">
        <link rel="stylesheet" href="<?= asset_url('icons/icomoon-light/style.css'); ?>">
        <link rel="stylesheet" href="<?= asset_url('bootstrap/bootstrap-light.css'); ?>">
        
        <?= $data['styles'] ?? ''; ?>

        <script src="<?= asset_url('bootstrap/bootstrap-light.js'); ?>"></script>

        <link rel="icon" href="<?= base_url('favicon.ico'); ?>" type="image/x-icon" />

    </head>
    <body class="bg-solitude">
<?php }


function get_footer()
{ ?>
    </body>
    </html>
<?php }



function get_navbar($appbar_brand = SITE_TITLE,$appbar_brand_url = null,$left_navbar = 'main',$appbar_label = '')
{?>
    
    <header class="appbar user-select-none">

        <div class="appbar-wrapper">

            <div class="appbar-section-left">
                <div onclick="open_navbar(navbar_left,overlay_left);" class="appbar-btn ripple"><b class="ic ic-menu"></b></div>
                <a class="appbar-brand ripple" href="<?= $appbar_brand_url  ?? base_url();; ?>"><?= $appbar_brand; ?></a>
            </div>

            <div class="appbar-section-right">
                <a data-prefix="ext" href="https://t.me/rytplays_jobs_group" class="appbar-btn ripple text-info"><b class="ic ic-telegram-c"></b></a>
                <div onclick="open_navbar(navbar_right,overlay_right)" class="appbar-btn ripple"><b class="ic ic-apps"></b></div>
            </div>

        </div>

        <div class="appbar-label"><?= $appbar_label ?></div>

    </header>

    <div class="navbar-overlay" id="overlay_left" onclick="close_navbar(navbar_left,overlay_left);"></div>
    <nav class="navbar user-select-none" id="navbar_left">
        <div class="navbar-header">
            <div class="navbar-brand ripple">MENU</div>
            <div onclick="close_navbar(navbar_left,overlay_left);" class="appbar-btn ripple"><b class="ic ic-close"></b></div>
        </div>
        <div class="navbar-links">
            <?php require(view('navbar-links/'.($left_navbar ?? 'main'))); ?>
        </div>
    </nav>

    <div class="navbar-overlay" id="overlay_right" onclick="close_navbar(navbar_right,overlay_right);"></div>
    <nav style="right: 0;" class="navbar user-select-none" id="navbar_right">
        <div class="navbar-header">
            <div class="navbar-brand ripple">MAIN MENU</div>
            <div onclick="close_navbar(navbar_right,overlay_right);" class="appbar-btn ripple"><b class="ic ic-close"></b></div>
        </div>
        <div class="navbar-links">
            <?php require(view('navbar-links/main')); ?>
        </div>
    </nav>


    <script type="text/javascript">
        const 
        navbar_left = GEBI('navbar_left'),
        overlay_left = GEBI('overlay_left'),
        navbar_right = GEBI('navbar_right'),
        overlay_right = GEBI('overlay_right');
    </script>
    

<?php } ?>


    
