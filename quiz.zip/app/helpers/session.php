<?php
class Session
{
    private static $is_session_started = false;

    public static function start()
    {
        if(self::$is_session_started == false)
        {
            session_start();
            self::$is_session_started = true;
        }
    }

    public static function destroy()
    {
        var_dump(self::$is_session_started);
        if(self::$is_session_started == true)
        {
            session_destroy();
        }
    }

    public static function set($key,$value)
    {
        $_SESSION[$key] = $value;
    }

    public static function has($key)
    {
        return isset($_SESSION[$key]);
    }

    public static function get($key)
    {
        return ($_SESSION[$key]);
    }

    public static function unset($key)
    {
        unset($_SESSION[$key]);
    }

    public static function regenerate_id()
    {
        session_regenerate_id();
    }

}
?>