<?php

function is_request_method($method)
{
    return $_SERVER['REQUEST_METHOD'] == $method;
}

function get_post_string($key)
{
    return (isset($_POST[$key]) && is_string($_POST[$key])) ? $_POST[$key] : '';
}

function get_get_string($key)
{
    return (isset($_GET[$key]) && is_string($_GET[$key])) ? $_GET[$key] : '';
}

function sanitize_text($text)
{
    return htmlspecialchars(htmlspecialchars_decode(trim($text)));
}

function sanitize_url($url)
{
    return filter_var($url,FILTER_SANITIZE_URL);
}

function sanitize_hst($data) 
{
    return htmlspecialchars(stripslashes(trim($data)));
}

function sanitize_slug($text,$max_length = 100)
{
    return preg_replace('~-+~', '-', trim(preg_replace('/[^A-Za-z0-9-]+/', '-',substr($text,0,$max_length)), '-'));
}

function sanitize_email($email)
{
    return filter_var($email,FILTER_SANITIZE_EMAIL);
}

function is_email($email)
{
    return filter_var($email,FILTER_VALIDATE_EMAIL) ? true : false;
}

function is_valid_url($url)
{
    return filter_var($url,FILTER_VALIDATE_URL);
}

function get_recaptcha_response($g_recaptcha_response) 
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 
    [
        'secret' => '6LcnqjQaAAAAAIhjMKggBDbmd-KxsqKqUtNcDLNV',
        'response' => $g_recaptcha_response,
        'remoteip' => $_SERVER['REMOTE_ADDR']
    ]);
    $response = json_decode(curl_exec($ch));
    curl_close($ch);
    return $response;
}
?>