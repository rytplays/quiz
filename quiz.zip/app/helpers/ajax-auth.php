<?php
Session::start();
if(Session::has('user_id') && Session::has('user_remember_key'))
{
    $current_user = $db->get('users','*',['id'=>Session::get('user_id')]);
    if($current_user != null)
    {
        if(strlen($current_user['remember_key']) == 16)
        {
            if(Session::get('user_remember_key') == $current_user['remember_key'])
            {
                
            }
            else
            {
                unset($current_user);
                ajax_response(403,'Session Expired');
            }
        }
        else
        {
            unset($current_user);
            ajax_response(403,'Unauthorized');
        }
    }
    else
    {
        unset($current_user);
        ajax_response(403,'Unauthorized');
    }
}
else
{
    ajax_response(401,'Unauthorized');
}

function user_has_permission($user_id,$permission)
{
    global $db;
    return $db->has('user_permissions',['user_id'=>$user_id,'permission'=>$permission]);
}
?>