<?php
use Josantonius\Url\Url;
$tag_slug = $tag_slug ?? 'latest';
require(helper('pagebuilder'));
$page = $_GET['page'] ?? '1';
if(ctype_digit($page) && $page > 0)
{
    define('CURRENT_URL', Url::getCurrentPage());
    $tag = $db->get('quiz_tags',['id','slug','name','thumbnail_url'],['slug'=>$tag_slug]);
    if($tag != null)
    {
        $limit = 10;
        $offset = ($page - 1) * $limit;

        $joins = 
        [
            '[><]quiz_post_tag' => ['id'=>'post_id'],
            '[><]quiz_tags' => ['quiz_post_tag.tag_id' => 'id'],
        ];

        $where = 
        [
            'quiz_tags.id' => $tag['id'],
            'quiz_posts.status' => 'P',
        ];

        $columns = 
        [
            'quiz_posts.id',
            'quiz_posts.slug',
            'quiz_posts.title',
            'quiz_posts.created_at',
            'quiz_posts.thumbnail_url',
        ];

        $total_quiz_posts = $db->count('quiz_posts',$joins,['quiz_posts.id'],$where);
        $total_pages = ceil( $total_quiz_posts / $limit );

        $where['LIMIT']=[$offset,$limit];
        $where['ORDER'] = ['created_at'=>'DESC'];
        $quiz_posts =  $db->select('quiz_posts',$joins,$columns,$where);

        if($total_pages > $page)
        {
            $get_params = $_GET;
            $get_params['page'] = ($page + 1);
            $next_page_url = CURRENT_URL.'?'.http_build_query($get_params);
        }
        else
        {
            $next_page_url = false;
        }

        if($page <= $total_pages && $page > 1)
        {
            $get_params = $_GET;
            $get_params['page'] = ($page - 1);
            $prev_page_url = CURRENT_URL.'?'.http_build_query($get_params);
        }
        else
        {
            $prev_page_url = false;
        }

        get_header
        (
            [
                'title_tag' => SITE_TITLE.' - '.$tag['name'],
                'description_tag' => $tag['name'].' - '.$tag['slug']
            ]
        );
        get_navbar(SITE_TITLE,base_url(),'quizzes',$tag['name']);
        require(view('index'));
    }
    else
    {
        display_error_page(404,'Tag Not Found');
    }
}
else
{
    display_error_page(404,'Invalid Page Number');
}








// get_quiz_posts_by_tag_slug();
// get_header();
// get_navbar(SITE_TITLE,base_url(),'quizzes','Home');
// require(view('home'));
// get_footer();
?>
