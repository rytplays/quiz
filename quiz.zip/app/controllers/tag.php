<?php
$tag_slug =  URL_SEGMENTS[2] ?? 'latest';
if(empty($tag_slug)) $tag_slug = 'latest';
require(controller('index'));
?>