<?php
header('Content-type:application/json');
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $quiz_post_id = $_POST['quiz_post_id'] ?? '';
    if(ctype_digit($quiz_post_id) && $quiz_post_id > 0)
    {
        ajax_response(200,'Fetched Successfully','',
        [
            'questions'=>$db->select('quiz_questions','*',['quiz_post_id'=>$quiz_post_id,'answer[!]'=>0]),
        ]);
    }
    else
    {
        ajax_response(400,'Invalid Quiz Id');
    }
}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>