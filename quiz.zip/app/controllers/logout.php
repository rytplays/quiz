<?php
require(helper('session'));
Session::start();
Session::destroy();
redirect(base_url('login'));
?>