<?php
header('Content-type:application/json');
require(helper('session'));
require(helper('ajax-auth'));

if($db->has('user_permissions',['user_id'=>$current_user['id'],'permission'=>'manage-quizzes']))
{
    if(TOTAL_URL_SEGMENTS > 2)
    {
        $admin_ajax_controller_file = controller('ajax-admin/'.URL_SEGMENTS[2]);
        if(file_exists($admin_ajax_controller_file))
        {
            require($admin_ajax_controller_file);
        }
        else
        {
            ajax_response(404,'Page Not Found');
        }
    }
    else
    {
        ajax_response(200,'Welcome to Admin Ajax');
    }
}
else
{
    ajax_response(403,'Forbidden');
}
?>