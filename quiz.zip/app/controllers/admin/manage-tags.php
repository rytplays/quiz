<?php
if(user_has_permission($current_user['id'],'manage-quiz-tags'))
{
    require(helper('request'));
    get_header(['title_tag'=>'My Tags']);

    $page_no = sanitize_text(get_get_string('page_no'));
    if(empty($page_no)) $page_no = '1';

    if(ctype_digit($page_no) && $page_no > 0)
    {
        $limit=10;
        $offset = ($page_no - 1)*$limit;
        $search_query = sanitize_text(get_get_string('search'));
        $where = [];
        if(!empty($search_query))
        {
            $where['OR'] = 
            [
                'slug[~]'=>$search_query,
                'name[~]'=>$search_query
            ];
        }
        $total_quiz_tags = $db->count('quiz_tags',['id'],$where);
        $total_pages=ceil($total_quiz_tags/$limit);

        if($total_pages > $page_no)
        {
            $get_params = $_GET;
            $get_params['page_no'] = ($page_no+1);
            $next_page_url = base_url('admin/manage-tags?'.http_build_query($get_params));
        }
        else
        {
            $next_page_url = false;
        }

        if($page_no <= $total_pages && $page_no > 1)
        {
            $get_params = $_GET;
            $get_params['page_no'] = ($page_no-1);
            $prev_page_url = base_url('admin/manage-tags?'.http_build_query($get_params));
        }
        else
        {
            $prev_page_url = false;
        }

        $where['ORDER'] = ['id'=>'DESC'];
        $where['LIMIT'] = [$offset,$limit];
        $quiz_tags = $db->select('quiz_tags',['id','slug','name','thumbnail_url'],$where);
        require(view('admin/manage-tags'));
        get_footer();
    }
    else
    {
        display_error_page(404,'Invalid page number');
    }
}
else
{
    display_error_page(403,'Forbidden');
}
?>