<?php
if(user_has_permission($current_user['id'],'manage-quiz-tags'))
{
    get_header(['title_tag'=>'Create Tag']);
    require(view('admin/create-tag'));
    get_footer();
}
else
{
    display_error_page(403,'Forbidden');
}
?>