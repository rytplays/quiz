<?php 
require(helper('request'));
$quiz_post_id = sanitize_text(get_get_string('quiz_post_id'));
$number = sanitize_text(get_get_string('number'));

if(ctype_digit($quiz_post_id) && $quiz_post_id > 0 && ctype_digit($number) && $number > 0)
{
    $quiz_post = $db->get('quiz_posts',['id','user_id'],['id'=>$quiz_post_id]);
    if($quiz_post != null)
    {
        if($quiz_post['user_id'] == $current_user['id'])
        {
            $question = $db->get('quiz_questions','*',['quiz_post_id'=>$quiz_post_id,'number'=>$number]);
            if($question != null)
            {
                get_header(['title_tag'=>'Update Question']);
                require(view('admin/update-question'));
                get_footer();
            }
            else
            {
                display_error_page(400,'Question not found');
            }
        }
        else
        {
            display_error_page(404,'Quiz not belongs to you');
        }
    }
    else
    {
        display_error_page(404,'Quiz not found');
    }
}
else
{
    display_error_page(404,'Invalid Quiz Id or question number');
}
?>