<?php
require(helper('request'));
$quiz_post_id = sanitize_text(get_get_string('quiz_post_id'));
if(ctype_digit($quiz_post_id) && $quiz_post_id > 0)
{
    $quiz_post = $db->get('quiz_posts',['id','user_id','slug','title'],['id'=>$quiz_post_id]);
    if($quiz_post != null)
    {
        if($quiz_post['user_id'] == $current_user['id'])
        {
            $all_quiz_tags = $db->select('quiz_tags',['id(value)','name(text)']);
            $related_quiz_tags = $db->select('quiz_post_tag',['tag_id'],['post_id'=>$quiz_post['id']]);
            $related_quiz_tag_ids_array = [];

            foreach($related_quiz_tags as $related_quiz_tag)
            {
                array_push($related_quiz_tag_ids_array,$related_quiz_tag['tag_id']);
            }
            
            get_header
            ([
                'title_tag'=>'Manage Tags',
                'styles'=>'<link href="'.asset_url('plugins/slimselect/style.css').'" rel="stylesheet"></link>',
                'scripts'=>'<script src="'.asset_url('plugins/slimselect/script.js').'"></script>'
            ]);
            require(view('admin/manage-relations'));
            get_footer();
        }
        else
        {
            display_error_page(404,'Quiz not belongs to you');
        }
    }
    else
    {
        display_error_page(404,'Quiz Post Not Found');
    }
}
else
{
    display_error_page(404,'Invalid Quiz Post Id');
}
?>