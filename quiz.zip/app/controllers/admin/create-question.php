<?php 
require(helper('request'));
$quiz_post_id = sanitize_text(get_get_string('quiz_post_id'));
if(ctype_digit($quiz_post_id) && $quiz_post_id > 0)
{
    $suggested_next_question = $db->max('quiz_questions','number',['quiz_post_id'=>$quiz_post_id]);
    $suggested_next_question = ($suggested_next_question + 1);

    get_header(['title_tag'=>'Create Question']);
    require(view('admin/create-question'));
    get_footer();
}
else
{
    display_error_page(404,'Invalid Quiz Id');
}
?>