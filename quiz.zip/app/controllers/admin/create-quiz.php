<?php
get_header(['title_tag'=>'Create Quiz']);
require(view('admin/create-quiz'));
get_footer();
?>