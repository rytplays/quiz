<?php
require(helper('request'));
get_header(['title_tag'=>'Manage Questions']);

$quiz_post_id = sanitize_text(get_get_string('quiz_post_id'));
if(ctype_digit($quiz_post_id) && $quiz_post_id > 0)
{
    $quiz_post = $db->get('quiz_posts',['id','user_id','slug','title'],['id'=>$quiz_post_id]);
    if($quiz_post != null)
    {
        if($quiz_post['user_id'] == $current_user['id'])
        {
            $page_no = sanitize_text(get_get_string('page_no'));
            if(empty($page_no)) $page_no = '1';
            if(ctype_digit($page_no) && $page_no > 0)
            {
                $limit=10;
                $offset = ($page_no-1)*$limit;
                $search_query = sanitize_text( get_get_string('search'));
                $where = [];
                $where['quiz_post_id'] = $quiz_post['id'];
                if(!empty($search_query))
                {
                    $where['OR'] = 
                    [
                        'title[~]'=>$search_query,
                        'number[~]'=>$search_query
                    ];
                }
                $total_quiz_questions = $db->count('quiz_questions',$where);
                $total_pages=ceil($total_quiz_questions/$limit);

                if($total_pages > $page_no)
                {
                    $get_params = $_GET;
                    $get_params['page_no'] = ($page_no+1);
                    $next_page_url = base_url('admin/manage-questions?'.http_build_query($get_params));
                }
                else
                {
                    $next_page_url = false;
                }

                if($page_no <= $total_pages && $page_no > 1)
                {
                    $get_params = $_GET;
                    $get_params['page_no'] = ($page_no-1);
                    $prev_page_url = base_url('admin/manage-questions?'.http_build_query($get_params));
                }
                else
                {
                    $prev_page_url = false;
                }

                $where['ORDER'] = ['number'=>'ASC'];
                $where['LIMIT'] = [$offset,$limit];
                $quiz_questions = $db->select('quiz_questions',['quiz_post_id','number','title'],$where);
                require(view('admin/manage-questions'));
                get_footer();
            }
            else
            {
                display_error_page(404,'Invalid Page number');
            }

        }
        else
        {
            display_error_page(403,'This Quiz Does not belongs to you');
        }
    }
    else
    {
        display_error_page(404,'Quiz Post Not Found');
    }
}
else
{
    display_error_page(404,'Quiz not found');
}


?>