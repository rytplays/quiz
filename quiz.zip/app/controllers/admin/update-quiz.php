<?php 
require(helper('request'));
$quiz_post_id = sanitize_text(get_get_string('quiz_post_id'));
if(ctype_digit($quiz_post_id) && $quiz_post_id > 0)
{
    $quiz_post = $db->get('quiz_posts','*',['id'=>$quiz_post_id]);
    if($quiz_post != null)
    {
        if($quiz_post['user_id'] == $current_user['id'])
        {
            get_header(['title_tag'=>'Update Quiz']);
            require(view('admin/update-quiz'));
            get_footer();
        }
        else
        {
            display_error_page(403,'This quiz does not belongs to you');
        }
    }
    else
    {
        display_error_page(404,'Quiz not found');
    }
}
else
{
    display_error_page(404,'Invalid quiz post id');
}
?>