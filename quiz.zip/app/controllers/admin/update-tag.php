<?php
if(user_has_permission($current_user['id'],'manage-quiz-tags'))
{
    require(helper('request'));
    $quiz_tag_id = sanitize_text(get_get_string('quiz_tag_id'));
    if(ctype_digit($quiz_tag_id) && $quiz_tag_id > 0)
    {
        $quiz_tag = $db->get('quiz_tags','*',['id'=>$quiz_tag_id]);
        if($quiz_tag != null)
        {
            get_header(['title_tag'=>'Update Tag']);
            require(view('admin/update-tag'));
            get_footer();
        }
        else
        {
            display_error_page(404,'Quiz Tag not found');
        }
    }
    else
    {
        display_error_page(404,'Invalid quiz tag id');
    }
}
else
{
    display_error_page(403,'Forbidden');
}
?>