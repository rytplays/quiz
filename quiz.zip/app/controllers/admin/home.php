<?php
require(helper('request'));
get_header(['title_tag'=>'My Quizzes']);

$page_no = sanitize_text(get_get_string('page_no'));
if(empty($page_no)) $page_no = '1';

if(ctype_digit($page_no) && $page_no > 0)
{
    $limit=10;
    $offset = ($page_no-1)*$limit;
    $search_query = sanitize_text(get_get_string('search'));
    $where = [];
    $where['user_id'] = $current_user['id'];
    if(!empty($search_query))
    {
        $where['OR'] = 
        [
            'title[~]'=>$search_query,
            'description[~]'=>$search_query,
            'slug[~]'=>$search_query,
        ];
    }
    $total_quiz_posts = $db->count('quiz_posts',['id'],$where);
    $total_pages=ceil($total_quiz_posts/$limit);

    if($total_pages > $page_no)
    {
        $get_params = $_GET;
        $get_params['page_no'] = ($page_no+1);
        $next_page_url = base_url('admin/?'.http_build_query($get_params));
    }
    else
    {
        $next_page_url = false;
    }

    if($page_no <= $total_pages && $page_no > 1)
    {
        $get_params = $_GET;
        $get_params['page_no'] = ($page_no-1);
        $prev_page_url = base_url('admin/?'.http_build_query($get_params));
    }
    else
    {
        $prev_page_url = false;
    }

    $where['ORDER'] = ['created_at'=>'DESC'];
    $where['LIMIT'] = [$offset,$limit];
    $quiz_posts = $db->select('quiz_posts',['id','slug','title','status'],$where);
    require(view('admin/home'));
    get_footer();
}
else
{
    display_error_page(404,'Invalid page number');
}
?>