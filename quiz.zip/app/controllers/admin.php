<?php
require(helper('admin-pagebuilder'));
require(helper('session'));
require(helper('auth'));

if($db->has('user_permissions',['user_id'=>$current_user['id'],'permission'=>'manage-quizzes']))
{
    if(TOTAL_URL_SEGMENTS > 2)
    {
        $admin_controller_file = controller('admin/'.URL_SEGMENTS[2]);
        if(file_exists($admin_controller_file))
        {
            require($admin_controller_file);
        }
        else
        {
            display_error_page(404,'PAGE NOT FOUND');
        }
    }
    else
    {
        $admin_controller_file = controller('admin/home');
        require($admin_controller_file);
    }
}
else
{
    display_error_page(403,'FORBIDDEN');
}
?>