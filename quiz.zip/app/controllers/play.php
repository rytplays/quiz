<?php 
$quiz_post_id = $_GET['id'];
if(ctype_digit($quiz_post_id) && $quiz_post_id > 0)
{
    $total_questions = $db->count('quiz_questions','*',['quiz_post_id'=>$quiz_post_id,'answer[!]'=>0]);
    if($total_questions > 0)
    {
        require(view('play'));
    }
    else
    {
        display_error_page(404,'NO QUESTIONS FOUND IN THIS QUIZ');
    }
}
else
{
    display_error_page(404,'Invalid quiz id');
}
?>