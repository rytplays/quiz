<?php
require(helper('request'));
if(is_request_method('POST'))
{
    $quiz_post_id = sanitize_text(get_post_string('quiz_post_id'));

    if(!ctype_digit($quiz_post_id)) ajax_response(400,'Bad Request','Invalid Quiz Post Id');
    if($quiz_post_id < 1) ajax_response(400,'Bad Request','Invalid Quiz Post Id');
    
    
    $quiz_post = $db->get('quiz_posts',['id','user_id'],['id'=>$quiz_post_id]);
    if($quiz_post != null)
    {
        if($quiz_post['user_id'] == $current_user['id'])
        {
            $questions = $db->select('quiz_questions','*',['quiz_post_id'=>$quiz_post['id']]);
            $ordered_questions = [];
            
            $total_questions = count($questions);

            if($total_questions > 0)
            {
                for($i = 0;$i < $total_questions; $i++)
                {
                    array_push($ordered_questions,[
                        'quiz_post_id' =>$quiz_post['id'],
                        'number' => ($i+1),
                        'title' => $questions[$i]['title'],
                        'option_1' =>$questions[$i]['option_1'],
                        'option_2' =>$questions[$i]['option_2'],
                        'option_3' =>$questions[$i]['option_3'],
                        'option_4' =>$questions[$i]['option_4'],
                        'answer' =>$questions[$i]['answer'],
                        'explaination' =>$questions[$i]['explaination'],
                    ]);
                }

                $db->delete('quiz_questions',['quiz_post_id'=>$quiz_post['id']]);
                try
                {
                    $db->insert('quiz_questions',$ordered_questions);
                    ajax_response(200,'Reoredered Successfully');
                }
                catch(PDOException $e)
                {
                    $db->insert('quiz_questions',$questions);
                    ajax_response(200,'Reoredered Failed',$e->getMessage());
                }
            }
            else
            {
                ajax_response(200,'No Question found in this quiz');
            }

        }
        else
        {
            ajax_response(403,'This quiz does not belongs to you');
        }
    }
    else
    {
        ajax_response(400,'Quiz not found');
    }

}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>