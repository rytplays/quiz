<?php
require(helper('request'));
if(is_request_method('POST'))
{
    $quiz_post_id = sanitize_text(get_post_string('quiz_post_id'));
    $slug = sanitize_slug(get_post_string('slug'),100);
    $status = get_post_string('status');
    $created_at = sanitize_text(get_post_string('created_at'));
    $updated_at = sanitize_text(get_post_string('updated_at'));
    $title = sanitize_text(get_post_string('title'));
    $thumbnail_url = sanitize_url(get_post_string('thumbnail_url'));
    $description = sanitize_text(get_post_string('description'));

    if(!ctype_digit($quiz_post_id)) ajax_response(400,'Bad Request','Invalid quiz id');
    
    $quiz_post_from_db = $db->get('quiz_posts',['id','user_id'],['id'=>$quiz_post_id]);
    if($quiz_post_from_db != null)
    {
        if($quiz_post_from_db['user_id'] == $current_user['id'])
        {
            if(empty($slug)) ajax_response(400,'Bad Request','Slug is Required');
            if($db->has('quiz_posts',['slug'=>$slug,'user_id[!]'=>$current_user['id']])) ajax_response(400,'Bad Request','Slug is already in use');

            if($status == 'D') $status = 'D';
            else if($status == 'P') $status = 'P';
            else ajax_response(400,'Bad Request','Invalid Status');

            $created_at = strtotime($created_at);
            if(!$created_at) ajax_response(400,'Bad Request','Invalid Created Time');

            $updated_at = strtotime($updated_at);
            if(!$updated_at) ajax_response(400,'Bad Request','Invalid Updated Time');

            if($created_at > $updated_at)  ajax_response(400,'Bad Request','Created time must be less than updated time');
    
            $created_at = date('Y-m-d H:i:s',$created_at);
            $updated_at = date('Y-m-d H:i:s',$updated_at);

            if(empty($title)) ajax_response(400,'Bad Request','Title is Required');
            else if(strlen($title) > 1000) ajax_response(400,'Bad Request','Title should not exceed 1000 charecters');

            if(!empty($thumbnail_url))
            {
                if(strlen($thumbnail_url) > 225) ajax_response(400,'Bad Request','Thumbnail URL should not exceed 255 charecters');
                else if(!is_valid_url($thumbnail_url)) ajax_response(400,'Bad Request','Invalid Thumbail URL');
            }

            if(strlen($description) > 20000) ajax_response(400,'Bad Request','Description should not exceed 20000 charecters');

            try
            {
                $db->update('quiz_posts',
                [
                    'slug'=>$slug,
                    'status'=>$status,
                    'created_at'=>$created_at,
                    'updated_at'=>$updated_at,
                    'title'=>$title,
                    'thumbnail_url'=>$thumbnail_url,
                    'description'=>$description
                ],
                [
                    'id'=>$quiz_post_from_db['id'],
                    'user_id'=>$current_user['id'],
                    'LIMIT'=>1
                ]);
                ajax_response(200,'Quiz updated successfully');
            }
            catch(PDOException $e)
            {
                ajax_response(500,'Internal Server Error',$e->getMessage());
            }
        }
        else
        {
            ajax_response(403,'Quiz not belongs to you');
        }
    }
    else
    {
        ajax_response(400,'Quiz not found');
    }
}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>