<?php
require(helper('request'));
if(is_request_method('POST'))
{
    if(user_has_permission($current_user['id'],'manage-quiz-tags'))
    {
        $quiz_tag_id = sanitize_text(get_post_string('quiz_tag_id'));

        if(!ctype_digit($quiz_tag_id)) ajax_response(400,'Bad Request','Quiz Tag Id is invalid');
        if($quiz_tag_id < 0) ajax_response(400,'Bad Request','Quiz Tag Id is invalid');

        if($db->has('quiz_tags',['id'=>$quiz_tag_id]))
        {
            try
            {
                $db->delete('quiz_tags',['id'=>$quiz_tag_id,'LIMIT'=>1]);
                ajax_response(200,'Tag Deleted Successfully');
            }
            catch(PDOException $e)
            {
                ajax_response(500,'Internal Server Error',$e->getMessage());
            }
        }
        else
        {
            ajax_response(400,'Quiz Tag Not Found');
        }
    }
    else
    {
        ajax_response(405,'Forbidden','You dont have permission to manage quiz tags');
    }
}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>