<?php
require(helper('request'));
if(is_request_method('POST'))
{
    $quiz_post_id = sanitize_text(get_post_string('quiz_post_id'));
    $number = sanitize_text(get_post_string('number'));
    $title = sanitize_text(get_post_string('title'));
    $option_1 = sanitize_text(get_post_string('option_1'));
    $option_2 = sanitize_text(get_post_string('option_2'));
    $option_3 = sanitize_text(get_post_string('option_3'));
    $option_4 = sanitize_text(get_post_string('option_4'));
    $answer = sanitize_text(get_post_string('answer'));
    $explaination = sanitize_text(get_post_string('explaination'));

    if(!ctype_digit($quiz_post_id)) ajax_response(400,'Bad Request','Invalid quiz post id');
    if($quiz_post_id < 1) ajax_response(400,'Bad Request','Invalid quiz post id');
    
    if(!ctype_digit($number)) ajax_response(400,'Bad Request','Invalid question number');
    if($number < 1) ajax_response(400,'Bad Request','Question number must be greater than 0');
    if($number > 999) ajax_response(400,'Bad Request','Question number must be less than 1000');
     
    if(empty($title)) ajax_response(403,'Bad Request','Title is Required');
    if(strlen($title) > 3000) ajax_response(400,'Bad Request','Title should not exceed 3000 charecters');
      
    if(strlen($option_1) > 1000) ajax_response(400,'Bad Request','Option 1 should not exceed 1000 charecters');
    if(strlen($option_2) > 1000) ajax_response(400,'Bad Request','Option 2 should not exceed 1000 charecters');
    if(strlen($option_3) > 1000) ajax_response(400,'Bad Request','Option 3 should not exceed 1000 charecters');
    if(strlen($option_4) > 1000) ajax_response(400,'Bad Request','Option 4 should not exceed 1000 charecters');

    if(!ctype_digit($answer)) ajax_response(400,'Bad Request','Answer must be in 1,2,3 or 4');
    if($answer < 0) ajax_response(400,'Bad Request','Answer must be in 1,2,3 or 4');
    if($answer > 4) ajax_response(400,'Bad Request','Answer must be in 1,2,3 or 4');
    
    if(strlen($explaination) > 5000) ajax_response(400,'Bad Request','Explaination should not exceed 5000 charecters');

    $quiz_post = $db->get('quiz_posts',['id','user_id'],['id'=>$quiz_post_id]);
    if($quiz_post != null)
    {
        if($quiz_post['user_id'] == $current_user['id'])
        {
            if($db->has('quiz_questions',['quiz_post_id'=>$quiz_post_id,'number'=>$number]))
            {
                ajax_response(403,'Bad Request','Question number already exists');
            }
            else
            {
                try
                {
                    $db->insert('quiz_questions',
                    [
                        'quiz_post_id'=>$quiz_post['id'],
                        'number'=>$number,
                        'title'=>$title,
                        'option_1'=>$option_1,
                        'option_2'=>$option_2,
                        'option_3'=>$option_3,
                        'option_4'=>$option_4,
                        'answer'=>$answer,
                        'explaination'=>$explaination
                    ]);
                    ajax_response(200,'Question created successfully','',[
                        'quiz_post_id'=>$quiz_post_id,
                        'number'=>$number
                    ]);
                }
                catch(PDOException $e)
                {
                    ajax_response(500,'Internal Server Error',$e->getMessage());
                }

            }
        }
        else
        {
            ajax_response(403,'This quiz does not belongs to you');
        }
    }
    else
    {
        ajax_response(400,'Quiz not found');
    }

}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>