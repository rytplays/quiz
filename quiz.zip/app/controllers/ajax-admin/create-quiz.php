<?php
require(helper('request'));
if(is_request_method('POST'))
{
    $title = sanitize_text(get_post_string('title'));
    $slug = sanitize_slug(get_post_string('slug'),100);

    if(empty($title)) ajax_response(400,'Bad Request','Title is Required');
    else if(strlen($title) > 1000) ajax_response(400,'Bad Request','Title should not exceed 1000 charecters');
    
    if(empty($slug)) ajax_response(400,'Bad Request','Slug is Required');
    if($db->has('quiz_posts',['slug'=>$slug])) ajax_response(400,'Bad Request','Slug is already in use');

    try
    {
        $db->insert('quiz_posts',['title'=>$title,'slug'=>$slug,'user_id'=>$current_user['id']]);
        ajax_response(200,'Quiz Created Successfully','',['quiz_post_id'=>$db->id()]);
    }
    catch(PDOException $e)
    {
        ajax_response(500,'Internal Server Error',$e->getMessage());
    }
    
}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>