<?php
require(helper('request'));
if(is_request_method('POST'))
{
    if(user_has_permission($current_user['id'],'manage-quiz-tags'))
    {
        $quiz_tag_id = sanitize_text(get_post_string('quiz_tag_id'));
        $slug = sanitize_slug(get_post_string('slug'),100);
        $name = sanitize_text(get_post_string('name'));
        $thumbnail_url = sanitize_url(get_post_string('thumbnail_url'));

        if(!ctype_digit($quiz_tag_id)) ajax_response(400,'Bad Request','Quiz Tag Id is invalid');
        if($quiz_tag_id < 0) ajax_response(400,'Bad Request','Quiz Tag Id is invalid');

        if(empty($slug)) ajax_response(400,'Bad Request','Slug is Required');
        if(strlen($name) > 1000) ajax_response(400,'Bad Request','Name should not exceed 1000 charecters');

        if(!empty($thumbnail_url))
        {
            if(strlen($thumbnail_url) > 255) ajax_response(400,'Bad Request','Thumbnail URL should not exceed 255 charecters');
            else if(!is_valid_url($thumbnail_url)) ajax_response(400,'Bad Request','Thumbnail URL is invalid');
        }

        if($db->has('quiz_tags',['id'=>$quiz_tag_id]))
        {
            if($db->has('quiz_tags',['slug'=>$slug,'id[!]'=>$quiz_tag_id])) ajax_response(400,'Bad Request','Slug already in use');
        
            try
            {
                $db->update('quiz_tags',['slug'=>$slug,'name'=>$name,'thumbnail_url'=>$thumbnail_url],['id'=>$quiz_tag_id,'LIMIT'=>1]);
                ajax_response(200,'Tag Updated Successfully');
            }
            catch(PDOException $e)
            {
                ajax_response(500,'Internal Server Error',$e->getMessage());
            }
        }
        else
        {
            ajax_response(400,'Quiz Tag Not Found');
        }
    }
    else
    {
        ajax_response(405,'Forbidden','You dont have permission to manage quiz tags');
    }
}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>