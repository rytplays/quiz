<?php
require(helper('request'));
if(is_request_method('POST'))
{
    $quiz_post_id = sanitize_text(get_post_string('quiz_post_id'));
    
    if(!ctype_digit($quiz_post_id)) ajax_response(400,'Bad Request','Invalid quiz post id');

    $quiz_post_from_db = $db->get('quiz_posts',['id','user_id'],['id'=>$quiz_post_id]);
    if($quiz_post_from_db != null)
    {
        if($quiz_post_from_db['user_id'] == $current_user['id'])
        {
            try
            {
                $db->delete('quiz_posts',
                [
                    'id'=>$quiz_post_from_db['id'],
                    'user_id'=>$current_user['id'],
                    'LIMIT'=>1
                ]);
                ajax_response(200,'Quiz deleted successfully');
            }
            catch(PDOException $e)
            {
                ajax_response(500,'Internal Server Error',$e->getMessage());
            }
        }
        else
        {
            ajax_response(403,'Quiz not belongs to you');
        }
    }
    else
    {
        ajax_response(400,'Quiz not found');
    }
}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>