<?php
require(helper('request'));
if(is_request_method('POST'))
{
    $quiz_post_id = sanitize_text(get_post_string('quiz_post_id'));
    $number = sanitize_text(get_post_string('number'));
    

    if(!ctype_digit($quiz_post_id)) ajax_response(400,'Bad Request','Invalid Quiz Post Id');
    if($quiz_post_id < 1) ajax_response(400,'Bad Request','Invalid Quiz Post Id');
    
    if(!ctype_digit($number)) ajax_response(400,'Bad Request','Invalid Question number');

    $quiz_post = $db->get('quiz_posts',['id','user_id'],['id'=>$quiz_post_id]);
    if($quiz_post != null)
    {
        if($quiz_post['user_id'] == $current_user['id'])
        {
            if($db->has('quiz_questions',['quiz_post_id'=>$quiz_post_id,'number'=>$number]))
            {
                try
                {
                    $db->delete('quiz_questions',['quiz_post_id'=>$quiz_post['id'],'number'=>$number,'LIMIT'=>1]);
                    ajax_response(200,'Question Deleted Successfully');
                }
                catch(PDOException $e)
                {
                    ajax_response(500,"Internal Server Error",$e->getMessage());
                }
            }
            else
            {
                ajax_response(400,'Bad Request','Quiz not found');
            }
        }
        else
        {
            ajax_response(403,'This quiz does not belongs to you');
        }
    }
    else
    {
        ajax_response(400,'Quiz not found');
    }

}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>