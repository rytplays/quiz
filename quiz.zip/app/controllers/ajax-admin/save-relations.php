<?php
require(helper('request'));
if(is_request_method('POST'))
{
    $quiz_post_id = sanitize_text(get_post_string('quiz_post_id'));
    $quiz_tag_ids = get_post_string('quiz_tag_ids');

    $quiz_tag_ids = json_decode($quiz_tag_ids);

    if(!ctype_digit($quiz_post_id)) ajax_response(400,'Bad Request','Invalid quiz post id');
    if($quiz_post_id < 1) ajax_response(400,'Bad Request','Invalid quiz post id');
    
    $quiz_post = $db->get('quiz_posts',['id','user_id'],['id'=>$quiz_post_id]);
    if($quiz_post != null)
    {
        if($quiz_post['user_id'] == $current_user['id'])
        {
            if(is_array($quiz_tag_ids))
            {
                if(count($quiz_tag_ids) == 0)
                {
                    try
                    {
                        $db->delete('quiz_post_tag',['post_id'=>$quiz_post_id]);
                        ajax_response(200,'All Tags Unrelated Successfully');
                    }
                    catch(PDOException $e)
                    {
                        ajax_response(500,'Internal Server Error',$e->getMessage());
                    }
                }
                else
                {
                    $db->delete('quiz_post_tag',['post_id'=>$quiz_post_id]);
                    $errors = [];
                    foreach($quiz_tag_ids as $quiz_tag_id)
                    {
                        if(ctype_digit($quiz_tag_id) && $db->has('quiz_tags',['id'=>$quiz_tag_id]))
                        {
                            try
                            {
                                $db->insert('quiz_post_tag',['post_id'=>$quiz_post_id,'tag_id'=>$quiz_tag_id]);
                            }
                            catch(PDOException $e)
                            {
                                array_push($errors,$e->getMessage());
                            }
                        }
                        else
                        {
                            array_push($errors,"Tag id $quiz_tag_id not found");
                        }
                    }
                    ajax_response(200,'Tagged Successfully','',['errors'=>$errors]);
                }
            }
            else
            {
                ajax_response(400,'Bad Request','Tag ids must be json array');
            }
        }
        else
        {
            ajax_response(403,'This quiz does not belongs to you');
        }
    }
    else
    {
        ajax_response(400,'Quiz not found');
    }

}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>