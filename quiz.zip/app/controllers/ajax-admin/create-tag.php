<?php
require(helper('request'));
if(is_request_method('POST'))
{
    if(user_has_permission($current_user['id'],'manage-quiz-tags'))
    {
        $slug = sanitize_slug(get_post_string('slug'),100);
        $name = sanitize_text(get_post_string('name'));

        if(empty($slug)) ajax_response(400,'Bad Request','Slug is Required');
        if(strlen($name) > 1000) ajax_response(400,'Bad Request','Name should not exceed 1000 charecters');

        if($db->has('quiz_tags',['slug'=>$slug])) ajax_response(400,'Bad Request','Slug already in use');
       
        try
        {
            $db->insert('quiz_tags',['slug'=>$slug,'name'=>$name]);
            ajax_response(200,'Tag Created Successfully','',['quiz_tag_id'=>$db->id()]);
        }
        catch(PDOException $e)
        {
            ajax_response(500,'Internal Server Error',$e->getMessage());
        }
    }
    else
    {
        ajax_response(405,'Forbidden','You dont have permission to manage quiz tags');
    }
}
else
{
    ajax_response(405,'Method Not Allowed');
}
?>