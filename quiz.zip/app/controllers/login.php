<?php
require(helper('request'));
$form_errors = [];
if(is_request_method('POST'))
{
    $recaptcha_response = get_recaptcha_response(get_post_string('g-recaptcha-response'));
    if($recaptcha_response != null && $recaptcha_response->success && $recaptcha_response->score >=0.5)
    {
        $email = sanitize_email(get_post_string('email'));
        $password = get_post_string('password');

        if(empty($email)) $form_errors['email'] = 'Email is required';
        else if(!is_email($email)) $form_errors['email'] = 'Email is Invalid';
        
        if(empty($password))
        {
            $form_errors['password'] = 'Password is required';
        }
        else
        {
            $password_length = strlen($password);
            if($password_length > 20)
            {
                $form_errors['password'] = 'Password should not exceed 20 charecters';
            }
            if($password_length < 8)
            {
                $form_errors['password'] = 'Password must be atleast 8 charecters';
            }
        }

        if(count($form_errors) == 0)
        {
            $user = $db->get('users',['id','email','password_hash','remember_key'],['email'=>$email]);
            if($user != null)
            {
                if(password_verify($password,$user['password_hash']))
                {
                    if(strlen($user['remember_key']) == 16)
                    {
                        $user_remember_key = $user['remember_key'];
                    }
                    else
                    {
                        $user_remember_key =  bin2hex(random_bytes(8));
                        $db->update('users',['remember_key'=>$user_remember_key],['id'=>$user['id'],'LIMIT'=>1]);
                    }
                    
                    require(helper('session'));
                    Session::start();
                    if(Session::has('login_referrer')) $redirected_from = Session::get('login_referrer');
                    else $redirected_from = base_url();
                    Session::unset('login_referrer');
                    
                    Session::regenerate_id();
                    Session::set('user_id',$user['id']);
                    Session::set('user_remember_key',$user['remember_key']);
                    redirect($redirected_from);
                }
                else
                {
                    $form_errors['password'] =  'Incorrect Password';
                }
            }
            else
            {
                $form_errors['email'] = 'Account not exists';
            }
        }
    }
    else
    {
        $form_errors['recaptcha'] = 'Failed to verify ReCaptcha. Please try again';
    }
}
require(helper('admin-pagebuilder'));
get_header(['title_tag'=>'Login']);
require(view('login'));
get_footer();
?>