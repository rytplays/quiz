<div class="bg-white" style="max-width : 100%">

    <div class="xcard r-0">
        <h1 class="h4 p-3 bold"><?= $quiz_post['title']; ?></h1>
        <div class="border-top px-3 py-1">
            <span class="btn">SHARE ON</span>
            <a href="https://wa.me/?text=<?= base_url($quiz_post['slug']); ?>" class="ic ic-whatsapp btn btn-success ms-2"></a>
            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= base_url($quiz_post['slug']); ?>" class="btn btn-primary ic  ic-facebook ms-2"></a>
        </div>
    </div>

    <div class="xcard r-0">
        <div class="px-3 py-1 d-flex justify-content-between">
        <div class="post-meta text-uppercase"> <b class="ic ic-updated"></b> <?= date('d M Y',strtotime($quiz_post['updated_at'])); ?> </div>
            <div class="post-meta text-uppercase"> <b class="ic ic-time"></b> <?= date('d M Y',strtotime($quiz_post['created_at'])); ?>  </div>
        </div>
    </div>

    <div class="text-center">
        <a class="btn btn-success btn-lg w-100 r-0" href="<?= base_url('play?id='.$quiz_post['id']); ?>">PLAY NOW</a>
    </div>

    <div class="ipost p-1">
        <div class="me-2">
            <div class="ipost-img" style="background-image: url('<?= $quiz_author['photo_url'] ?>');"></div>
        </div>
        <div>
        <div class="ipost-date"> <b class="ic ic-user">  </b> CREATED BY </div>
            <div class="ipost-title"><?= $quiz_author['name']; ?></div>
        </div>
    </div>

    <?php if(!empty($quiz_post['description'])) : ?>
    <div class="p-2">
        <div class="xcard p-3">
            <?= $quiz_post['description']; ?>
        </div>
    </div>
    <?php endif; ?>

</div>