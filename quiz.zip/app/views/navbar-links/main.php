<a href="">Home</a>
<a href="">Jobs</a>
<a href="">Study Materials</a>
<a href="">Quizzes</a>