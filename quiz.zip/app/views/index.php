<div style="max-width: 100%;">
    <?php if($total_quiz_posts > 0) : foreach($quiz_posts as $quiz_post) : ?>
            <a href="<?= base_url($quiz_post['slug']); ?>" class="ipost p-1">
                <div class="me-2">
                    <div class="ipost-img" style="background-image: url('<?= $quiz_post['thumbnail_url'] ?>');"></div>
                </div>
                <div>
                    <div class="ipost-title"><?= $quiz_post['title']; ?></div>
                    <div class="ipost-date"> <b class="ic ic-time">  </b><?= date('d M Y',strtotime($quiz_post['created_at'])); ?></div>
                </div>
            </a>
    <?php endforeach; else :  ?>
        <div class="p-3">
            <div style="max-width: 400px;" class="p-3 xcard mx-auto my-5 text-center">
                <div class="mb-4 bold">NO QUIZZES FOUND IN THIS PAGE</div>
                <a class="btn btn-primary" href="<?= base_url(); ?>">BACK TO HOME</a>
            </div>
        </div>
    <?php endif; ?>
</div>


<div class="d-flex justify-content-center my-5">
    <a href="<?= $prev_page_url; ?>" class="btn btn-dark r-0" <?php if($prev_page_url == false) echo 'hidden'; ?>>PREV</a>
    <a href="<?= $next_page_url; ?>" class="btn btn-dark r-0" <?php if($next_page_url == false) echo 'hidden'; ?>>NEXT</a>
</div>

