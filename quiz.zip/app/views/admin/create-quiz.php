<div style="max-width: 100%;">
    
    <div class="shadow-sm d-flex align-items-center user-select-none bg-white">
        <?php get_drawer(['left_drawer_links'=>'admin/drawer-links/main']); ?>
        <div class="ms-2"><b>CREATE QUIZ</b></div>
    </div>

    <div class="p-3">
        <form class="border py-3 px-4 shadow-sm bg-white" id="form_create_quiz">
            <div class="mb-3">
                <label for="textarea_title" class="form-label-sm">Title</label>
                <textarea id="textarea_title" rows="1" class="form-control r-0"></textarea>
            </div>
            <div class="mb-3">
                <label for="input_slug" class="form-label-sm">Slug</label>
                <input type="text" id="input_slug"  class="form-control r-0" />
            </div>
            <button class="btn btn-primary r-0">Continue</button>
        </form>
    </div>

</div>


<script>
    var mDialog = new dialog();
    mDialog.header.setAttribute('class','bold text-center border-bottom p-3 text-uppercase');
    mDialog.body.setAttribute('class','hie p-3 text-uppercase');
    $(function()
    {
        $('#form_create_quiz').on('submit',function(e)
        {
            e.preventDefault();
            mDialog.loading();
            $.post
            ({
                url : "<?= base_url('ajax-admin/create-quiz') ?>",
                data : 
                {
                    "title" : $("#textarea_title").val(),
                    "slug" : $("#input_slug").val()
                }
            })
            .done(function(response)
            {
                if(typeof(response) == "object")
                {
                    mDialog.setContent(response.msg,response.desc);
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-success',function()
                    {
                        location.href = "<?= base_url('admin/update-quiz?quiz_post_id=') ?>"+response.data.quiz_post_id;
                    });
                }
                else
                {
                    console.log(response);
                    mDialog.setContent('Something went wrong','Please see the console');
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-danger',function(){ mDialog.hide(); })
                }
                mDialog.show();
            })
            .fail(function(response)
            {
                var responseJSON = response.responseJSON;
                if(typeof(responseJSON) == "object")
                {
                    mDialog.setContent(responseJSON.msg,responseJSON.desc);
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-warning',function(){ mDialog.hide(); });
                }
                else
                {
                    console.log(response);
                    mDialog.setContent('Something went wrong','Please see console for more details');
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-danger',function(){ mDialog.hide(); });
                }
                mDialog.show();
            });
        });
    });
</script>