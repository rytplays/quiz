<a href="<?= base_url('admin'); ?>">My Quizzes</a>
<a href="<?= base_url('admin/create-quiz'); ?>">Create Quiz</a>
<a href="<?= base_url('admin/manage-tags'); ?>">Manage Tags</a>
<a href="<?= base_url('logout'); ?>">Logout</a>




