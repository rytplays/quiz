<div style="max-width: 100%;">

    <form class="" id="form_create_question">
        
        <div class="shadow-sm d-flex align-items-center user-select-none bg-white">
            <?php get_drawer(['left_drawer_links'=>'admin/drawer-links/main']); ?>
            <div class="ms-2"><b>CREATE QUESTION</b></div>
            <div style="flex: 1;"></div>
            <button class="btn btn-primary" type="submit">SAVE</button>
        </div>

        <div class="p-3">
            <input value="<?= $suggested_next_question; ?>" id="input_number"  type="text" rows="1" class="form-control r-0 mb-2" placeholder="Question Number"/>
            <textarea id="textarea_title" rows="1" class="form-control r-0 mb-2" placeholder="Title"></textarea>
            <textarea id="textarea_option_1" rows="1" class="form-control r-0 mb-2" placeholder="Option 1"></textarea>
            <textarea id="textarea_option_2" rows="1" class="form-control r-0 mb-2" placeholder="Option 2"></textarea>
            <textarea id="textarea_option_3" rows="1" class="form-control r-0 mb-2" placeholder="Option 3"></textarea>
            <textarea id="textarea_option_4" rows="1" class="form-control r-0 mb-2" placeholder="Option 4"></textarea>
            <select class="form-select mb-2 r-0" id="select_answer">
                <option value="0" selected>Select Answer</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
            </select>
            <textarea id="textarea_explaination" rows="1" class="form-control r-0 mb-2" placeholder="Explaination"></textarea>
        </div>

    </form>

</div>

<script>
    var mDialog = new dialog();
    mDialog.header.setAttribute('class','bold text-center border-bottom p-3 text-uppercase');
    mDialog.body.setAttribute('class','hie p-3 text-uppercase');
    $(function()
    {
        $('#form_create_question').on('submit',function(e)
        {
            e.preventDefault();
            mDialog.loading();
            $.post
            ({
                url : "<?= base_url('ajax-admin/create-question') ?>",
                data : 
                {
                    "quiz_post_id" : "<?= sanitize_text(get_get_string('quiz_post_id')); ?>",
                    "number" : $("#input_number").val(),
                    "title" : $("#textarea_title").val(),
                    "option_1" : $("#textarea_option_1").val(),
                    "option_2" : $("#textarea_option_2").val(),
                    "option_3" : $("#textarea_option_3").val(),
                    "option_4" : $("#textarea_option_4").val(),
                    "answer" : $("#select_answer").val(),
                    "explaination" : $("#textarea_explaination").val(),
                }
            })
            .done(function(response)
            {
                if(typeof(response) == "object")
                {
                    mDialog.setContent(response.msg,response.desc);
                    mDialog.setBtn1('ADD NEXT QUESTION','btn btn-primary',function()
                    {
                        location.reload();
                    });
                    mDialog.setBtn2('EDIT','btn btn-success',function()
                    {
                        location.href = "<?= base_url('admin/update-question?quiz_post_id=') ?>"+response.data.quiz_post_id+"&number="+response.data.number;
                    });
                }
                else
                {
                    console.log(response);
                    mDialog.setContent('Something went wrong','Please see the console');
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-danger',function(){ mDialog.hide(); });
                }
                mDialog.show();
                
            })
            .fail(function(response)
            {
                var responseJSON = response.responseJSON;
                if(typeof(responseJSON) == "object")
                {
                    mDialog.setContent(responseJSON.msg,responseJSON.desc);
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-warning',function(){ mDialog.hide(); });
                    mDialog.show();
                }
                else
                {
                    console.log(response);
                    mDialog.setContent('Something went wrong','Please see console for more details');
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-danger',function(){ mDialog.hide(); })
                    mDialog.show();
                }
            });
        });
    });
</script>