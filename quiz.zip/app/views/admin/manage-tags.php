<div style="max-width: 100%;">
    
    <div class="shadow-sm d-flex align-items-center user-select-none bg-white position-sticky top-0">
        <?php get_drawer(['left_drawer_links'=>'admin/drawer-links/main']); ?>
        <div class="ms-2"><b>MANAGE TAGS</b></div>
        <div style="flex: 1;"></div>
        <a href="<?= base_url('admin/create-tag'); ?>" class="btn btn-primary btn-sm mx-1"><b class="ic ic-add"></b></a>
    </div>

    <main class="p-3">
        <form action="<?= base_url('admin/manage-tags'); ?>" method="get" class="d-flex">
            <input type="search" name="search" class="form-control r-0" placeholder="Search">
            <button type="submit" class="btn btn-primary r-0">Search</button>
        </form>
        <div class="mt-2">
            <?php foreach($quiz_tags as $quiz_tag):?>
            <div>
                <div class="shadow-sm border bg-white mb-2">
                    <div id="quiz_tag_title_<?= $quiz_tag['id']; ?>" class="p-2"><?= $quiz_tag['name']; ?></div>
                    <div class="d-flex justify-content-between p-2 border-top">
                        <a class="btn btn-outline-warning btn-sm" href="<?= base_url('admin/update-tag?quiz_tag_id='.$quiz_tag['id']); ?>"><b class="ic ic-edit"></b></a>
                        <a class="btn btn-outline-danger btn-sm" href="javascript:delete_quiz_tag('<?= $quiz_tag['id']; ?>')"><b class="ic ic-delete"></b></a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

    <div class="d-flex justify-content-center my-5">
        <a href="<?= $prev_page_url; ?>" class="btn btn-light r-0" <?php if($prev_page_url == false) echo 'hidden'; ?>>PREV</a>
        <a href="<?= $next_page_url; ?>" class="btn btn-light r-0" <?php if($next_page_url == false) echo 'hidden'; ?>>NEXT</a>
    </div>

</div>


<script>
    var mDialog = new dialog();
    mDialog.header.setAttribute('class','bold text-center border-bottom p-3 text-uppercase');
    mDialog.body.setAttribute('class','hie p-3 text-uppercase');
    
    function delete_quiz_tag(quiz_tag_id)
    {
        mDialog.loading();
        mDialog.setContent('Are you sure to delete the tag',$('#quiz_tag_title_'+quiz_tag_id).html())
        mDialog.setBtn2('CANCEL','btn btn-secondary',function(){ mDialog.hide(); });
        mDialog.setBtn1('DELETE','btn btn-danger',function()
        {
            mDialog.loading();
            $.post
            ({
                url : "<?= base_url('ajax-admin/delete-tag') ?>",
                data : 
                {
                    "quiz_tag_id" : quiz_tag_id,
                }
            })
            .done(function(response)
            {
                if(typeof(response) == "object")
                {
                    mDialog.setContent(response.msg,response.desc);
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-success',function()
                    {
                        location.reload();
                    });
                }
                else
                {
                    console.log(response);
                    mDialog.setContent('Something went wrong','Please see the console');
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-danger',function(){ mDialog.hide(); })
                }
                mDialog.show();
                
            })
            .fail(function(response)
            {
                var responseJSON = response.responseJSON;
                if(typeof(responseJSON) == "object")
                {
                    mDialog.setContent(responseJSON.msg,responseJSON.desc);
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-warning',function(){mDialog.hide();})
                    mDialog.show();
                }
                else
                {
                    console.log(response);
                    mDialog.setContent('Something went wrong','Please see console for more details');
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-danger',function(){mDialog.hide();})
                    mDialog.show();
                }
            });
        });
        mDialog.show();

        return ;
        
    }
</script>

