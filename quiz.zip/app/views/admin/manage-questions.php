<div style="max-width: 100%;">
    
    <div class="shadow-sm d-flex align-items-center user-select-none bg-white position-sticky top-0">
        <?php get_drawer(['left_drawer_links'=>'admin/drawer-links/main']); ?>
        <div style="flex: 1;" class="ms-2 me-2 text-truncate" onclick="location.href='<?= base_url('admin/manage-questions?quiz_post_id='.$quiz_post['id']); ?>'"><b><?= $quiz_post['title'] ?></b></div>
        <a href="<?= base_url('admin/create-question?quiz_post_id='.$quiz_post['id']); ?>" class="btn btn-primary btn-sm"><b class="ic ic-add"></b></a>
        <button class="btn btn-dark btn-sm ms-1 me-1" onclick="reorder_questions('<?= $quiz_post['id']; ?>');"><b class="ic ic-reorder"></b></button>
    </div>

    <div class="p-3">
        <form action="<?= base_url('admin/manage-questions'); ?>" method="get" class="d-flex mb-2">
            <input type="hidden" name="quiz_post_id" value="<?= $quiz_post['id']; ?>">
            <input type="search" name="search" class="form-control r-0 shadow-sm" placeholder="Search">
            <button type="submit" class="btn btn-primary r-0">Search</button>
        </form>
        <div>
            <?php foreach($quiz_questions as $question) : ?>
            <div>
                <div class="shadow-sm mb-2 border bg-white">
                    <div id="question_title_<?= $question['number']; ?>" class="p-2"><?= $question['number']; ?>) <?= $question['title']; ?></div>
                    <div class="d-flex justify-content-between p-2 border-top">
                        <a class="btn btn-outline-warning btn-sm" href="<?= base_url('admin/update-question?quiz_post_id='.$quiz_post['id'].'&number='.$question['number']); ?>"><b class="ic ic-edit"></b></a>
                        <a class="btn btn-outline-danger btn-sm" href="javascript:delete_question('<?= $quiz_post['id']; ?>','<?= $question['number']; ?>')"><b class="ic ic-delete"></b></a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="d-flex justify-content-center my-5">
        <a href="<?= $prev_page_url; ?>" class="btn btn-light r-0" <?php if($prev_page_url == false) echo 'hidden'; ?>>PREV</a>
        <a href="<?= $next_page_url; ?>" class="btn btn-light r-0" <?php if($next_page_url == false) echo 'hidden'; ?>>NEXT</a>
    </div>

</div>


<script>
    var mDialog = new dialog();
    mDialog.header.setAttribute('class','bold text-center border-bottom p-3 text-uppercase');
    mDialog.body.setAttribute('class','hie p-3 text-uppercase');
    
    function delete_question(quiz_post_id,number)
    {
        mDialog.loading();
        mDialog.setContent('Are you sure to delete the question',$('#question_title_'+number).html())
        mDialog.setBtn1('DELETE','btn btn-danger',function()
        {
            mDialog.loading();
            $.post
            ({
                url : "<?= base_url('ajax-admin/delete-question') ?>",
                data : 
                {
                    "quiz_post_id" : quiz_post_id,
                    "number" : number
                }
            })
            .done(function(response)
            {
                if(typeof(response) == "object")
                {
                    mDialog.setContent(response.msg,response.desc);
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-success',function()
                    {
                        location.reload();
                    }); 
                }
                else
                {
                    console.log(response);
                    mDialog.setContent('Something went wrong','Please see the console');
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-danger',function(){mDialog.hide();})
                }
                mDialog.show();
                
            })
            .fail(function(response)
            {
                var responseJSON = response.responseJSON;
                if(typeof(responseJSON) == "object")
                {
                    mDialog.setContent(responseJSON.msg,responseJSON.desc);
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-warning',function(){mDialog.hide();})
                    mDialog.show();
                }
                else
                {
                    console.log(response);
                    mDialog.setContent('Something went wrong','Please see console for more details');
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-danger',function(){mDialog.hide();})
                    mDialog.show();
                }
            });
        });
        mDialog.setBtn2('CANCEL','btn btn-secondary',function(){
            mDialog.hide();
        });
        mDialog.show();

        return ;
        
    }

    var nDialog = new dialog();
    nDialog.header.setAttribute('class','bold text-center border-bottom p-3 text-uppercase');
    nDialog.body.setAttribute('class','hie p-3 text-uppercase');
    function reorder_questions(quiz_post_id)
    {
        nDialog.loading();
        nDialog.setContent('Are you sure to reorder questions','');
        nDialog.setBtn1('REORDER','btn btn-danger',function()
        {
            nDialog.loading();
            $.post
            ({
                url : "<?= base_url('ajax-admin/reorder-questions') ?>",
                data : 
                {
                    "quiz_post_id" : quiz_post_id,
                }
            })
            .done(function(response)
            {
                if(typeof(response) == "object")
                {
                    nDialog.setContent(response.msg,response.desc);
                    nDialog.setBtn2();
                    nDialog.setBtn1('OK','btn btn-success',function()
                    {
                        location.reload();
                    }); 
                }
                else
                {
                    console.log(response);
                    nDialog.setContent('Something went wrong','Please see the console');
                    nDialog.setBtn2();
                    nDialog.setBtn1('OK','btn btn-danger',function(){nDialog.hide();})
                }
                nDialog.show();
                
            })
            .fail(function(response)
            {
                var responseJSON = response.responseJSON;
                if(typeof(responseJSON) == "object")
                {
                    nDialog.setContent(responseJSON.msg,responseJSON.desc);
                    nDialog.setBtn2();
                    nDialog.setBtn1('OK','btn btn-warning',function(){nDialog.hide();})
                    nDialog.show();
                }
                else
                {
                    console.log(response);
                    nDialog.setContent('Something went wrong','Please see console for more details');
                    nDialog.setBtn2();
                    nDialog.setBtn1('OK','btn btn-danger',function(){nDialog.hide();})
                    nDialog.show();
                }
            });
        });
        nDialog.setBtn2('CANCEL','btn btn-secondary',function(){
            nDialog.hide();
        });
        nDialog.show();

        return ;
        
    }
</script>

