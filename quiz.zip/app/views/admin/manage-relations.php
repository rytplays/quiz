
<div class="bg-white shadow-sm d-flex align-items-center">
   <?php get_drawer(['left_drawer_links'=>'admin/drawer-links/main']); ?>
   <div class="ms-2"><b>MANAGE RELATIONS</b></div>
   <div style="flex: 1;"></div>
   <button class="btn btn-primary btn-sm mx-1" onclick="save_relations();">SAVE</button>
</div>

<main>
   <div class="alert alert-primary text-truncate">
      <?= $quiz_post['title']; ?>
   </div>
   <div class="p-2"><select id="select" multiple></select></div>
</main>


<script>
var select = new SlimSelect
({
    select: '#select',
    closeOnSelect: false,
    hideSelectedOption: true,
});
select.setData( <?php echo json_encode($all_quiz_tags); ?>);
select.set( <?php echo json_encode($related_quiz_tag_ids_array); ?> );

var mDialog = new dialog();
mDialog.header.setAttribute('class','bold text-center border-bottom p-3 text-uppercase');
mDialog.body.setAttribute('class','hie p-3 text-uppercase');

function save_relations()
{
   var selected_tag_ids = JSON.stringify(select.selected());
   mDialog.loading();
   $.post
   ({
         url : "<?= base_url('ajax-admin/save-relations') ?>",
         data : 
         {
            "quiz_post_id" : <?= $quiz_post['id']; ?>,
            "quiz_tag_ids" : selected_tag_ids,
         }
   })
   .done(function(response)
   {
         if(typeof(response) == "object")
         {
            mDialog.setContent(response.msg,response.desc);
            mDialog.setBtn2();
            mDialog.setBtn1('OK','btn btn-success',function()
            {
               location.reload();
            });
         }
         else
         {
            console.log(response);
            mDialog.setContent('Something went wrong','Please see the console');
            mDialog.setBtn2();
            mDialog.setBtn1('OK','btn btn-danger',function(){ mDialog.hide(); })
         }
         mDialog.show();
   })
   .fail(function(response)
   {
         var responseJSON = response.responseJSON;
         if(typeof(responseJSON) == "object")
         {
            mDialog.setContent(responseJSON.msg,responseJSON.desc);
            mDialog.setBtn2();
            mDialog.setBtn1('OK','btn btn-warning',function(){ mDialog.hide(); });
         }
         else
         {
            console.log(response);
            mDialog.setContent('Something went wrong','Please see console for more details');
            mDialog.setBtn2();
            mDialog.setBtn1('OK','btn btn-danger',function(){ mDialog.hide(); });
         }
         mDialog.show();
   });
}
</script>

