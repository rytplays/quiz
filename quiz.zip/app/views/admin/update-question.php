<div style="max-width: 100%;">

    <form class="" id="form_update_question">
        
        <div class="shadow-sm d-flex align-items-center user-select-none position-sticky top-0 bg-white">
            <?php get_drawer(['left_drawer_links'=>'admin/drawer-links/main']); ?>
            <div class="ms-2"><b>UPDATE QUESTION</b></div>
            <div style="flex: 1;"></div>
            <button class="btn btn-primary" type="submit">UPDATE</button>
        </div>

        <div class="p-3">

        <?= ($question['explaination']); ?>

            <div class="d-flex justify-content-between">
                <div>
                    <label for="input_old_number" class="form-label-sm">Old Question Number</label>
                    <input id="input_old_number"  type="text" class="form-control r-0 mb-2 border border-dark" disabled="true" title="Old Question Number" value="<?= $question['number']; ?>"/>
                </div>
                <div>
                    <label for="input_new_number" class="form-label-sm">New Question Number</label>
                    <input id="input_new_number"  type="text" class="form-control r-0 mb-2" placeholder="New Question Number" title="New Question Number" value="<?= $question['number']; ?>"/>
                </div>
            </div>

            <div>
                <label for="textarea_title" class="form-label-sm">Question Title</label>
                <textarea id="textarea_title" rows="2" class="form-control r-0 mb-2" placeholder="Title"><?= $question['title']; ?></textarea>
            </div>

            <textarea id="textarea_option_1" rows="1" class="form-control r-0 mb-2" placeholder="Option 1"><?= $question['option_1']; ?></textarea>
            <textarea id="textarea_option_2" rows="1" class="form-control r-0 mb-2" placeholder="Option 2"><?= $question['option_2']; ?></textarea>
            <textarea id="textarea_option_3" rows="1" class="form-control r-0 mb-2" placeholder="Option 3"><?= $question['option_3']; ?></textarea>
            <textarea id="textarea_option_4" rows="1" class="form-control r-0 mb-2" placeholder="Option 4"><?= $question['option_4']; ?></textarea>
            
            <div>
                <label for="input_answer" class="form-label-sm">Answer</label>
                <input id="input_answer"  type="text" rows="1" class="form-control r-0 mb-2" placeholder="Answer" value="<?= $question['answer']; ?>"/>
            </div>

            <div>
                <label for="textarea_explaination" class="form-label-sm">Explaination</label>
                <textarea id="textarea_explaination" rows="1" class="form-control r-0 mb-2" placeholder="Explaination"><?= $question['explaination']; ?></textarea>
            </div>
            
        </div>

    </form>

</div>



<script>
    var mDialog = new dialog();
    mDialog.header.setAttribute('class','bold text-center border-bottom p-3 text-uppercase');
    mDialog.body.setAttribute('class','hie p-3 text-uppercase');
    $(function()
    {
        $('#form_update_question').on('submit',function(e)
        {
            e.preventDefault();
            mDialog.loading();
            $.post
            ({
                url : "<?= base_url('ajax-admin/update-question') ?>",
                data : 
                {
                    "quiz_post_id" : "<?= $quiz_post['id']; ?>",
                    "old_number" : $("#input_old_number").val(),
                    "new_number" : $("#input_new_number").val(),
                    "title" : $("#textarea_title").val(),
                    "option_1" : $("#textarea_option_1").val(),
                    "option_2" : $("#textarea_option_2").val(),
                    "option_3" : $("#textarea_option_3").val(),
                    "option_4" : $("#textarea_option_4").val(),
                    "answer" : $("#input_answer").val(),
                    "explaination" : $("#textarea_explaination").val(),
                }
            })
            .done(function(response)
            {
                if(typeof(response) == "object")
                {
                    mDialog.setContent(response.msg,response.desc);
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-success',function()
                    {
                        location.href = "<?= base_url('admin/update-question?quiz_post_id=') ?>"+response.data.quiz_post_id+"&number="+response.data.number;
                    });
                }
                else
                {
                    console.log(response);
                    mDialog.setContent('Something went wrong','Please see the console');
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-danger',function(){ mDialog.hide(); });
                }
                mDialog.show();
                
            })
            .fail(function(response)
            {
                var responseJSON = response.responseJSON;
                if(typeof(responseJSON) == "object")
                {
                    mDialog.setContent(responseJSON.msg,responseJSON.desc);
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-warning',function(){ mDialog.hide(); });
                    mDialog.show();
                }
                else
                {
                    console.log(response);
                    mDialog.setContent('Something went wrong','Please see console for more details');
                    mDialog.setBtn2();
                    mDialog.setBtn1('OK','btn btn-danger',function(){ mDialog.hide(); });
                    mDialog.show();
                }
            });
        });
    })
</script>