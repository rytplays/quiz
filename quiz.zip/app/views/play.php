<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Play Quiz</title>
    <link rel="stylesheet" href="<?= asset_url('fonts/product-sans/style.css'); ?>">
    <link rel="stylesheet" href="<?= asset_url('icons/icomoon-light/style.css'); ?>">
    <link rel="stylesheet" href="<?= asset_url('play/style.css'); ?>">
    <link rel="icon" href="<?= base_url('favicon.ico'); ?>" type="image/x-icon" />
</head>
<body>

    <div id="loader"><div class="loader"></div></div>

    <div id="main">
        <div id="quiz_panel">
            <div id="title_bar">
                <div onclick="load_question(current_question - 1);" id="btn_prev" class="ripple"><b class="ic ic-arrow-left"></b></div>
                <div id="btn_score" class="ripple">0</div>
                <div id="btn_number" class="ripple"></div>
                <div onclick="load_question(current_question + 1);" id="btn_next" class="ripple"><b class="ic ic-arrow-right"></b></div>
            </div>
            <div id="question_panel">
                <div id="title"></div>
                <div id="options">
                    <div id="option_1" data-position="1" ></div>
                    <div id="option_2" data-position="2" ></div>
                    <div id="option_3" data-position="3" ></div>
                    <div id="option_4" data-position="4" ></div>
                </div>
            </div>
        </div>
        <div id="score_panel" style="padding: 1rem;">
            <table id="score_table">
                <tr>
                    <th id="th_score_title" colspan="2">SCORE BOARD</th>
                </tr>
                <tr>
                    <td>Total Questions</td>
                    <td id="td_total_questions"></td>
                </tr>
                <tr>
                    <td>Attended Questions</td>
                    <td id="td_attended_questions"></td>
                </tr>
                <tr style="background-color: #c2ffc4;">
                    <td>Correct answers</td>
                    <td id="td_correct_questions"></td>
                </tr>
                <tr style="background-color: #ffebde;">
                    <td>Wrong answers</td>
                    <td id="td_incorrect_questions"></td>
                </tr>
            </table>
            
            <div id="progressbar">
                <div id="progress"></div>
            </div>

            <div style="display: flex;justify-content : space-between;">
                <button style="background-color: blue;" class="btn" onclick="hide_score_panel();">REVIEW</button>
                <button style="background-color: green;" class="btn" onclick="location.reload();">PLAY AGAIN</button>
                <button style="background-color: orangered;" class="btn" onclick="go_to_home();">HOME</button>
            </div>

        </div>
    </div>

    <script>
        const
        quiz_post_id = '<?= $_GET['id']; ?>',
        base_url = '<?= base_url(); ?>',
        audio_correct = new Audio('<?= asset_url('play/correct.mp3'); ?>'),
        audio_wrong = new Audio('<?= asset_url('play/wrong.mp3'); ?>');
    </script>
    <script src="<?= asset_url('play/script.js'); ?>"></script>

</body>
</html>