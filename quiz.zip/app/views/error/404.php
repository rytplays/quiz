<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $msg; ?></title>
    <style>
        body
        {
            margin: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }
        .btn
        {
            padding: 0.5rem 1.2rem;
            background-color: dodgerblue;
            color: white;
            text-decoration:none;
            font-weight:bold;
            border-radius: 100rem;
            box-shadow : 0 0 0.8rem #e1e1e1;
        }
    </style>
</head>
<body style="text-align : center;">
    <h1 style="padding : 1rem;"><?= $msg; ?></h1>
    <p style="padding : 1rem;"><?= $desc; ?></p>
    <?php if($default_button) :  ?>
        <a class="btn" href="<?= $default_button['url'] ?? base_url(); ?>"><?= $default_button['text'] ?? 'BACK TO HOME'; ?></a>
    <?php endif; ?>
</body>
</html>