<?php if(isset($form_errors['recaptcha'])) : ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong><?= $form_errors['recaptcha']; ?></strong>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>


<script src="https://www.google.com/recaptcha/api.js"></script>
<form id="form_login" style="max-width: 300px;" class="mx-auto border p-3 my-5 bg-white shadow-sm" action="<?= base_url('login'); ?>" method="post">
    <div class="mb-3">
        <label for="input_email" class="form-label-sm">Email</label>
        <input type="text" name="email" id="input_email" class="form-control" value="<?= $email ?? ''; ?>">
        <div class="form-error"><?= $form_errors['email'] ?? ''; ?></div>
    </div>
    <div class="mb-3">
        <label for="input_password" class="form-label-sm">Password</label>
        <input type="text" name="password" id="input_password" class="form-control">
        <div class="form-error"><?= $form_errors['password'] ?? ''; ?></div>
    </div>
    <button class="g-recaptcha btn btn-primary w-100" data-sitekey="6LcnqjQaAAAAAMqJrYVqzordhn7dAMQ2wG78sHuM" data-callback='login' data-action='submit'>Login</button>
</form>

<script>
    function login(token) 
    {
        document.getElementById("form_login").submit();
    }
</script>