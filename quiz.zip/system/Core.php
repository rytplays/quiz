<?php
use Medoo\Medoo;
require(SYSTEM_PATH.'Medoo.php');
require(SYSTEM_PATH.'Url.php');

function base_url($uri = '')
{
    return BASE_URL.$uri;
}

function asset_url($uri = '')
{
    return BASE_URL.'assets/'.$uri.'?v=1614860791';
}

function view($path)
{
   return VIEWS_PATH.$path.'.php';
}

function controller($path)
{
   return CONTROLLERS_PATH.$path.'.php';
}

function helper($path)
{
    return HELPERS_PATH.$path.'.php';
}

function model($path)
{
    return MODELS_PATH.$path.'.php';
}

function display_error_page($code,$msg,$desc = '',$default_button = true)
{
    http_response_code($code);
    require(view('error/404'));
    exit();
}

function ajax_response($code,$msg,$desc = '',$data = null)
{
    http_response_code($code);
    exit(json_encode([
        'code'=>$code,
        'msg'=>$msg,
        'desc'=>$desc,
        'data'=>$data
    ]));
}

function db_connect()
{
    return new Medoo
    ([
        'database_type' => 'mysql',
        'database_name' => 'rytplays_career',
        'server' => 'localhost',
        'username' => 'rytplays_admin',
        'password' => '112600R=r',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_general_ci',
    ]);
}

function redirect($to)
{
    header('Location:'.$to);
    exit();
}

function set_value($value,$escape = true)
{
   return $escape ? htmlspecialchars($value) : $value;
}

?>