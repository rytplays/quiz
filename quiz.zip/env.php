<?php
define('BASE_URL','http://local.test/quiz/');
define('DS', DIRECTORY_SEPARATOR);
define('BASE_PATH', __DIR__.DS);
define('SYSTEM_PATH', BASE_PATH.'system'.DS);
define('APP_PATH', BASE_PATH.'app'.DS);
define('CONTROLLERS_PATH', APP_PATH.'controllers'.DS);
define('MODELS_PATH', APP_PATH.'models'.DS);
define('HELPERS_PATH', APP_PATH.'helpers'.DS);
define('VIEWS_PATH', APP_PATH.'views'.DS);

define('SITE_TITLE', 'RYTPLAYS QUIZZES');

?>