<?php
use Josantonius\Url\Url;

require(__DIR__.DIRECTORY_SEPARATOR.'env.php');
require(SYSTEM_PATH.'Core.php');

define('URL_SEGMENTS', array_slice(Url::segmentUri(Url::getCurrentPage()),3));
define('TOTAL_URL_SEGMENTS', count(URL_SEGMENTS));



$db = db_connect();
if(TOTAL_URL_SEGMENTS > 1)
{
    $controller_file = controller(URL_SEGMENTS[1]);
    if(file_exists($controller_file))
    {
        require($controller_file);
    }
    else
    {
        $quiz_post = $db->get('quiz_posts','*',['slug'=>URL_SEGMENTS['1']]);
        if($quiz_post != null)
        {
            $quiz_author = $db->get('users',['name','photo_url','about'],['id'=>$quiz_post['user_id']]);
            require(helper('pagebuilder'));
            get_header();
            get_navbar(SITE_TITLE,base_url(),'quizzes');
            require(view('page'));
            get_footer();
        }
        else
        {
            display_error_page(404,'PAGE NOT FOUND');
        }
    }
}
else
{
    $controller_file = CONTROLLERS_PATH.'index.php';
    require($controller_file);
}
?>